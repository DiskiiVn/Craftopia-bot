$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
npm ci
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed' }
npm run tauri build -- --bundles nsis
if ($LASTEXITCODE -ne 0) { throw 'Windows build failed' }
New-Item -ItemType Directory -Force release | Out-Null
$exe = Get-ChildItem 'src-tauri/target/release/bundle/nsis/*.exe' | Select-Object -First 1
if (!$exe) { throw 'Installer was not produced' }
Copy-Item $exe.FullName 'release/Axolot-Client-Setup-0.13.0-Aurora.exe'
Get-FileHash 'release/Axolot-Client-Setup-0.13.0-Aurora.exe' -Algorithm SHA256
