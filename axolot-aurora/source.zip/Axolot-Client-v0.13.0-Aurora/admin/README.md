# Axolot Client Admin

Production admin portal: https://axolot-client-updates-pter.vercel.app

The portal writes configuration through the `axolot-admin-config` Supabase Edge Function. Players never receive the CurseForge API key. Launcher clients only read public configuration and call the CurseForge proxy.

Managed values:
- Microsoft Application (Client) ID
- CurseForge API key
- update manifest URL
- latest launcher version

Security:
- Admin access uses a high-entropy token. Only its SHA-256 hash is stored in the private database schema.
- CurseForge key is stored in `axolot_private.launcher_config`, a schema not exposed to anon/authenticated Data API roles.
- Microsoft Client ID is intentionally public and is delivered through `axolot-public-config`.
