use futures_util::{stream, StreamExt};
use regex::Regex;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha1::{Digest as Sha1Digest, Sha1};
use sha2::{Digest as Sha2Digest, Sha256};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::Emitter;

#[derive(Debug, Serialize, Deserialize)]
struct ManifestFile {
    path: String,
    url: String,
    sha256: String,
    #[serde(default)]
    required: bool,
}

#[derive(Debug, Serialize, Deserialize)]
struct ClientManifest {
    launcher_version: String,
    client_version: String,
    minecraft: String,
    loader: String,
    files: Vec<ManifestFile>,
}

#[derive(Debug, Serialize, Deserialize)]
struct ModFileEntry {
    name: String,
    enabled: bool,
    size_bytes: u64,
}

#[derive(Debug, Deserialize)]
struct ModrinthSearchResponse {
    hits: Vec<ModrinthHit>,
}

#[derive(Debug, Serialize, Deserialize)]
struct ModrinthHit {
    project_id: String,
    title: String,
    description: String,
    #[serde(default)]
    icon_url: Option<String>,
    #[serde(default)]
    author: String,
    #[serde(default)]
    downloads: u64,
    #[serde(default)]
    versions: Vec<String>,
    #[serde(default)]
    categories: Vec<String>,
    project_type: String,
}

#[derive(Debug, Deserialize)]
struct ModrinthVersion {
    #[serde(default)]
    files: Vec<ModrinthVersionFile>,
}

#[derive(Debug, Deserialize)]
struct ModrinthVersionFile {
    url: String,
    filename: String,
    #[serde(default)]
    primary: bool,
}

#[derive(Debug, Deserialize)]
struct MrPackIndex {
    #[serde(default)]
    files: Vec<MrPackFile>,
}

#[derive(Debug, Deserialize)]
struct MrPackFile {
    path: String,
    #[serde(default)]
    hashes: HashMap<String, String>,
    #[serde(default)]
    downloads: Vec<String>,
    #[serde(rename = "fileSize", default)]
    file_size: u64,
}

#[derive(Debug, Deserialize)]
struct CurseForgeManifest {
    #[serde(default)]
    files: Vec<CurseForgeManifestFile>,
    #[serde(default = "default_overrides_folder")]
    overrides: String,
}

fn default_overrides_folder() -> String { "overrides".into() }

#[derive(Debug, Deserialize)]
struct CurseForgeManifestFile {
    #[serde(rename = "projectID")]
    project_id: u64,
    #[serde(rename = "fileID")]
    file_id: u64,
    #[serde(default = "default_true")]
    required: bool,
}

fn default_true() -> bool { true }

#[derive(Debug, Serialize)]
struct OptimizationPackResult {
    installed: Vec<String>,
    failed: Vec<String>,
    preset: String,
    message: String,
}

#[derive(Debug, Serialize, Clone)]
struct LaunchProgress {
    stage: String,
    message: String,
    percent: u8,
}

#[derive(Debug, Serialize)]
struct LaunchResult {
    pid: u32,
    profile_dir: String,
    java_runtime: String,
    message: String,
}

#[derive(Debug, Serialize, Clone)]
struct GameProcessStatus {
    profile_id: String,
    state: String,
    pid: Option<u32>,
    exit_code: Option<i32>,
    message: String,
}

#[derive(Debug, Serialize, Clone)]
struct GameConsoleLine {
    profile_id: String,
    stream: String,
    timestamp_ms: u128,
    line: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct CrashLine {
    number: usize,
    level: String,
    text: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct CrashReport {
    profile_id: String,
    exit_code: Option<i32>,
    summary: String,
    source: String,
    lines: Vec<CrashLine>,
    suspicious: Vec<CrashLine>,
}


#[derive(Debug, Serialize, Deserialize, Clone)]
struct MicrosoftDeviceCode {
    device_code: String,
    user_code: String,
    verification_uri: String,
    message: String,
    expires_in: u64,
    interval: u64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct MicrosoftLoginResult {
    account_id: String,
    username: String,
    uuid: String,
    xuid: String,
    expires_at_ms: u128,
}

#[derive(Debug, Serialize, Clone)]
struct MicrosoftLoginProgress {
    stage: String,
    message: String,
    percent: u8,
}

fn emit_microsoft_progress(app: &tauri::AppHandle, stage: &str, message: impl Into<String>, percent: u8) {
    let _ = app.emit("microsoft-login-progress", MicrosoftLoginProgress {
        stage: stage.to_string(),
        message: message.into(),
        percent,
    });
}

#[derive(Debug, Clone)]
struct MicrosoftSession {
    account_id: String,
    username: String,
    uuid: String,
    xuid: String,
    access_token: String,
    client_id: String,
    expires_at_ms: u128,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct LauncherUpdateManifest {
    version: String,
    download_url: String,
    sha256: String,
    #[serde(default)]
    notes: String,
    #[serde(default)]
    mandatory: bool,
}

#[derive(Debug, Serialize, Clone)]
struct LauncherUpdateStatus {
    current_version: String,
    latest_version: String,
    available: bool,
    download_url: String,
    sha256: String,
    notes: String,
    mandatory: bool,
}

static MICROSOFT_SESSIONS: OnceLock<Mutex<HashMap<String, MicrosoftSession>>> = OnceLock::new();

fn microsoft_sessions() -> &'static Mutex<HashMap<String, MicrosoftSession>> {
    MICROSOFT_SESSIONS.get_or_init(|| Mutex::new(HashMap::new()))
}

static GAME_STATES: OnceLock<Mutex<HashMap<String, GameProcessStatus>>> = OnceLock::new();

fn game_states() -> &'static Mutex<HashMap<String, GameProcessStatus>> {
    GAME_STATES.get_or_init(|| Mutex::new(HashMap::new()))
}

fn set_game_state(app: &tauri::AppHandle, status: GameProcessStatus) {
    if let Ok(mut states) = game_states().lock() {
        states.insert(status.profile_id.clone(), status.clone());
    }
    let _ = app.emit("game-status", status);
}

fn now_millis() -> u128 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis()).unwrap_or(0)
}

fn classify_log_line(text: &str) -> String {
    let lower = text.to_ascii_lowercase();
    if lower.contains("fatal") || lower.contains("[error]") || lower.contains(" error ") || lower.starts_with("error") {
        "error".into()
    } else if lower.contains("exception") || lower.contains("caused by:") || text.trim_start().starts_with("at ") || text.trim_start().starts_with("at\t") || text.trim_start().starts_with("at net.") || text.trim_start().starts_with("at com.") {
        "stack".into()
    } else if lower.contains("[warn]") || lower.contains("warning") {
        "warn".into()
    } else {
        "info".into()
    }
}

fn newest_crash_file(profile_id: &str) -> Option<PathBuf> {
    let root = profile_root(profile_id).ok()?.join("crash-reports");
    let mut files = std::fs::read_dir(root).ok()?.flatten()
        .map(|entry| entry.path())
        .filter(|path| path.extension().and_then(|x| x.to_str()).map(|x| x.eq_ignore_ascii_case("txt")).unwrap_or(false))
        .filter_map(|path| {
            let modified = std::fs::metadata(&path).ok()?.modified().ok()?;
            Some((modified, path))
        })
        .collect::<Vec<_>>();
    files.sort_by_key(|(modified, _)| *modified);
    files.pop().map(|(_, path)| path)
}

fn build_crash_report(profile_id: &str, exit_code: Option<i32>) -> CrashReport {
    let crash_file = newest_crash_file(profile_id);
    let log_file = profile_root(profile_id).ok().map(|p| p.join("logs").join("latest.log"));
    let source_path = crash_file.clone().or(log_file).unwrap_or_else(|| PathBuf::from("latest.log"));
    let text = std::fs::read_to_string(&source_path).unwrap_or_else(|_| "No crash report or latest.log was found.".into());
    let raw_lines = text.lines().collect::<Vec<_>>();
    let start = raw_lines.len().saturating_sub(1200);
    let lines = raw_lines[start..].iter().enumerate().map(|(index, text)| {
        CrashLine { number: start + index + 1, level: classify_log_line(text), text: (*text).to_string() }
    }).collect::<Vec<_>>();
    let suspicious = lines.iter().filter(|line| line.level != "info").cloned().take(160).collect::<Vec<_>>();
    let summary = suspicious.iter().find(|line| line.level == "error" || line.level == "stack")
        .map(|line| line.text.clone())
        .unwrap_or_else(|| format!("Minecraft exited unexpectedly with code {}.", exit_code.map(|v| v.to_string()).unwrap_or_else(|| "unknown".into())));
    CrashReport {
        profile_id: profile_id.into(),
        exit_code,
        summary,
        source: source_path.to_string_lossy().to_string(),
        lines,
        suspicious,
    }
}

#[derive(Debug, Deserialize)]
struct MojangVersionManifest {
    versions: Vec<MojangVersionRef>,
}

#[derive(Debug, Deserialize)]
struct MojangVersionRef {
    id: String,
    url: String,
}

const AXOLOT_CORE_BYTES: &[u8] = include_bytes!("../resources/axolot-client-core.jar");
const USER_AGENT: &str = "AxolotClient/0.13.0 (+https://axolot.local)";
const AXOLOT_CURSEFORGE_PROXY: &str = "https://rlbgvgosxrhqnppbrtey.supabase.co/functions/v1/axolot-curseforge";

fn emit_progress(app: &tauri::AppHandle, stage: &str, message: impl Into<String>, percent: u8) {
    let _ = app.emit(
        "launch-progress",
        LaunchProgress {
            stage: stage.into(),
            message: message.into(),
            percent,
        },
    );
}

fn app_root() -> Result<PathBuf, String> {
    let base = dirs::data_dir().ok_or("Không tìm thấy thư mục AppData")?;
    Ok(base.join("AxolotClient"))
}

fn shared_game_root() -> Result<PathBuf, String> {
    Ok(app_root()?.join("minecraft"))
}

fn safe_segment(value: &str) -> String {
    value
        .chars()
        .filter(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_' | '.' | ' '))
        .collect::<String>()
        .trim()
        .replace(' ', "_")
}

fn profile_root(profile_id: &str) -> Result<PathBuf, String> {
    let safe = safe_segment(profile_id);
    if safe.is_empty() {
        return Err("Profile ID không hợp lệ".into());
    }
    Ok(app_root()?.join("profiles").join(safe))
}

fn mods_dir(profile_id: &str) -> Result<PathBuf, String> {
    Ok(profile_root(profile_id)?.join("mods"))
}

fn modpacks_dir(profile_id: &str) -> Result<PathBuf, String> {
    Ok(profile_root(profile_id)?.join("modpacks"))
}

fn safe_file_name(file_name: &str) -> Result<String, String> {
    let file_name = Path::new(file_name)
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or("Tên file không hợp lệ")?;
    let safe = safe_segment(file_name);
    if safe.is_empty() {
        return Err("Tên file không hợp lệ".into());
    }
    Ok(safe)
}

fn sha1_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha1::digest(bytes))
}

async fn download_bytes(client: &reqwest::Client, url: &str) -> Result<Vec<u8>, String> {
    client
        .get(url)
        .header("User-Agent", USER_AGENT)
        .send()
        .await
        .map_err(|e| format!("Không tải được {url}: {e}"))?
        .error_for_status()
        .map_err(|e| format!("Server trả về lỗi cho {url}: {e}"))?
        .bytes()
        .await
        .map(|b| b.to_vec())
        .map_err(|e| e.to_string())
}

async fn ensure_download(
    client: &reqwest::Client,
    url: &str,
    path: &Path,
    expected_sha1: Option<&str>,
    expected_size: Option<u64>,
) -> Result<bool, String> {
    if let Ok(meta) = tokio::fs::metadata(path).await {
        let size_ok = expected_size.map(|s| s == meta.len()).unwrap_or(true);
        if size_ok {
            if let Some(hash) = expected_sha1 {
                if let Ok(existing) = tokio::fs::read(path).await {
                    if sha1_hex(&existing).eq_ignore_ascii_case(hash) {
                        return Ok(false);
                    }
                }
            } else {
                return Ok(false);
            }
        }
    }

    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await.map_err(|e| e.to_string())?;
    }
    let bytes = download_bytes(client, url).await?;
    if let Some(hash) = expected_sha1 {
        let actual = sha1_hex(&bytes);
        if !actual.eq_ignore_ascii_case(hash) {
            return Err(format!("SHA-1 không khớp khi tải {}", path.display()));
        }
    }
    tokio::fs::write(path, bytes).await.map_err(|e| e.to_string())?;
    Ok(true)
}

fn offline_uuid(username: &str) -> String {
    let input = format!("OfflinePlayer:{username}");
    let mut digest = md5::compute(input.as_bytes()).0;
    digest[6] = (digest[6] & 0x0f) | 0x30;
    digest[8] = (digest[8] & 0x3f) | 0x80;
    digest.iter().map(|b| format!("{b:02x}")).collect()
}

fn version_parts(version: &str) -> (u32, u32, u32) {
    let clean = version.trim_start_matches("Minecraft ");
    let mut it = clean.split('.').filter_map(|part| part.parse::<u32>().ok());
    (it.next().unwrap_or(1), it.next().unwrap_or(21), it.next().unwrap_or(0))
}

fn required_java_major(version: &str) -> u8 {
    let (major, minor, patch) = version_parts(version);
    if major > 1 || minor >= 21 || (minor == 20 && patch >= 5) {
        21
    } else if minor >= 18 {
        17
    } else if minor >= 17 {
        17
    } else {
        8
    }
}

fn find_file_recursive(root: &Path, file_name: &str) -> Option<PathBuf> {
    let entries = std::fs::read_dir(root).ok()?;
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_file() && path.file_name().and_then(|n| n.to_str()).map(|n| n.eq_ignore_ascii_case(file_name)).unwrap_or(false) {
            return Some(path);
        }
        if path.is_dir() {
            if let Some(found) = find_file_recursive(&path, file_name) {
                return Some(found);
            }
        }
    }
    None
}

fn extract_zip_file(zip_path: &Path, destination: &Path, excludes: &[String]) -> Result<(), String> {
    std::fs::create_dir_all(destination).map_err(|e| e.to_string())?;
    let file = File::open(zip_path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;

    for i in 0..archive.len() {
        let mut item = archive.by_index(i).map_err(|e| e.to_string())?;
        let Some(name) = item.enclosed_name().map(|p| p.to_owned()) else { continue };
        let name_text = name.to_string_lossy().replace('\\', "/");
        if excludes.iter().any(|exclude| name_text.starts_with(exclude)) {
            continue;
        }
        let out = destination.join(name);
        if item.is_dir() {
            std::fs::create_dir_all(&out).map_err(|e| e.to_string())?;
        } else {
            if let Some(parent) = out.parent() {
                std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let mut output = File::create(&out).map_err(|e| e.to_string())?;
            std::io::copy(&mut item, &mut output).map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}


fn safe_relative_path(value: &str) -> Result<PathBuf, String> {
    let path = Path::new(value);
    if path.is_absolute() || path.components().any(|component| matches!(component, std::path::Component::ParentDir | std::path::Component::RootDir | std::path::Component::Prefix(_))) {
        return Err(format!("Unsafe archive path: {value}"));
    }
    Ok(path.to_path_buf())
}

fn parse_mrpack_index(archive_path: &Path) -> Result<MrPackIndex, String> {
    let file = File::open(archive_path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    let mut item = archive.by_name("modrinth.index.json").map_err(|_| "Modpack thiếu modrinth.index.json".to_string())?;
    let mut text = String::new();
    item.read_to_string(&mut text).map_err(|e| e.to_string())?;
    serde_json::from_str(&text).map_err(|e| format!("modrinth.index.json không hợp lệ: {e}"))
}

fn parse_curseforge_manifest(archive_path: &Path) -> Result<CurseForgeManifest, String> {
    let file = File::open(archive_path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    let mut item = archive.by_name("manifest.json").map_err(|_| "Modpack CurseForge thiếu manifest.json".to_string())?;
    let mut text = String::new();
    item.read_to_string(&mut text).map_err(|e| e.to_string())?;
    serde_json::from_str(&text).map_err(|e| format!("manifest.json không hợp lệ: {e}"))
}

fn extract_archive_prefix(zip_path: &Path, destination: &Path, prefix: &str) -> Result<(), String> {
    let prefix = format!("{}/", prefix.trim_matches('/'));
    let file = File::open(zip_path).map_err(|e| e.to_string())?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    for i in 0..archive.len() {
        let mut item = archive.by_index(i).map_err(|e| e.to_string())?;
        let name = item.name().replace('\\', "/");
        let Some(relative) = name.strip_prefix(&prefix) else { continue };
        if relative.is_empty() { continue; }
        let relative = safe_relative_path(relative)?;
        let out = destination.join(relative);
        if item.is_dir() {
            std::fs::create_dir_all(&out).map_err(|e| e.to_string())?;
        } else {
            if let Some(parent) = out.parent() { std::fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
            let mut output = File::create(&out).map_err(|e| e.to_string())?;
            std::io::copy(&mut item, &mut output).map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

async fn ensure_java_runtime(app: &tauri::AppHandle, game_version: &str) -> Result<PathBuf, String> {
    #[cfg(not(target_os = "windows"))]
    {
        let _ = app;
        let _ = game_version;
        return Err("Axolot Client release hiện hỗ trợ Windows trước.".into());
    }

    #[cfg(target_os = "windows")]
    {
        let major = required_java_major(game_version);
        let runtime_root = app_root()?.join("runtimes").join(format!("temurin-{major}"));
        if let Some(java) = find_file_recursive(&runtime_root, "java.exe").or_else(|| find_file_recursive(&runtime_root, "javaw.exe")) {
            return Ok(java);
        }

        emit_progress(app, "java", format!("Đang cài Java {major} runtime..."), 8);
        tokio::fs::create_dir_all(&runtime_root).await.map_err(|e| e.to_string())?;
        let archive_path = app_root()?.join("cache").join(format!("temurin-{major}-windows-x64.zip"));
        if let Some(parent) = archive_path.parent() {
            tokio::fs::create_dir_all(parent).await.map_err(|e| e.to_string())?;
        }
        let url = format!("https://api.adoptium.net/v3/binary/latest/{major}/ga/windows/x64/jre/hotspot/normal/eclipse");
        let client = reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::limited(10))
            .build()
            .map_err(|e| e.to_string())?;
        ensure_download(&client, &url, &archive_path, None, None).await?;

        let root_clone = runtime_root.clone();
        let archive_clone = archive_path.clone();
        tokio::task::spawn_blocking(move || extract_zip_file(&archive_clone, &root_clone, &[]))
            .await
            .map_err(|e| e.to_string())??;

        find_file_recursive(&runtime_root, "java.exe")
            .or_else(|| find_file_recursive(&runtime_root, "javaw.exe"))
            .ok_or_else(|| format!("Không tìm thấy java.exe sau khi cài Java {major}"))
    }
}

fn current_os_name() -> &'static str {
    if cfg!(target_os = "windows") { "windows" }
    else if cfg!(target_os = "macos") { "osx" }
    else { "linux" }
}

fn rule_applies(rule: &Value) -> bool {
    if let Some(os) = rule.get("os") {
        if let Some(name) = os.get("name").and_then(Value::as_str) {
            if name != current_os_name() {
                return false;
            }
        }
        if let Some(arch) = os.get("arch").and_then(Value::as_str) {
            let current_arch = if cfg!(target_arch = "x86") { "x86" } else { "x86_64" };
            if arch != current_arch && !(arch == "x86_64" && current_arch == "x86_64") {
                return false;
            }
        }
        if let Some(pattern) = os.get("version").and_then(Value::as_str) {
            if let Ok(regex) = Regex::new(pattern) {
                let os_version = std::env::var("OS").unwrap_or_default();
                if !regex.is_match(&os_version) {
                    return false;
                }
            }
        }
    }

    if let Some(features) = rule.get("features").and_then(Value::as_object) {
        for (_key, required) in features {
            if required.as_bool().unwrap_or(false) {
                return false;
            }
        }
    }
    true
}

fn rules_allow(rules: Option<&Value>) -> bool {
    let Some(rules) = rules.and_then(Value::as_array) else { return true };
    let mut allowed = false;
    for rule in rules {
        if rule_applies(rule) {
            allowed = rule.get("action").and_then(Value::as_str) == Some("allow");
        }
    }
    allowed
}

fn maven_path(name: &str) -> Result<String, String> {
    let mut split_ext = name.split('@');
    let coordinate = split_ext.next().unwrap_or(name);
    let extension = split_ext.next().unwrap_or("jar");
    let parts: Vec<&str> = coordinate.split(':').collect();
    if parts.len() < 3 {
        return Err(format!("Maven coordinate không hợp lệ: {name}"));
    }
    let group = parts[0].replace('.', "/");
    let artifact = parts[1];
    let version = parts[2];
    let classifier = parts.get(3).map(|v| format!("-{v}")).unwrap_or_default();
    Ok(format!("{group}/{artifact}/{version}/{artifact}-{version}{classifier}.{extension}"))
}

async fn get_vanilla_version_json(client: &reqwest::Client, game_version: &str) -> Result<Value, String> {
    let manifest: MojangVersionManifest = client
        .get("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
        .header("User-Agent", USER_AGENT)
        .send()
        .await
        .map_err(|e| format!("Không tải được Minecraft version manifest: {e}"))?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| format!("Version manifest không hợp lệ: {e}"))?;

    let version = manifest
        .versions
        .into_iter()
        .find(|v| v.id == game_version)
        .ok_or_else(|| format!("Minecraft {game_version} chưa có trong manifest chính thức"))?;

    client
        .get(version.url)
        .header("User-Agent", USER_AGENT)
        .send()
        .await
        .map_err(|e| e.to_string())?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| format!("Version JSON không hợp lệ: {e}"))
}

async fn get_fabric_profile(client: &reqwest::Client, game_version: &str) -> Result<Value, String> {
    let url = format!("https://meta.fabricmc.net/v2/versions/loader/{game_version}");
    let list: Vec<Value> = client
        .get(&url)
        .header("User-Agent", USER_AGENT)
        .send()
        .await
        .map_err(|e| format!("Không tải được Fabric loader list: {e}"))?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| e.to_string())?;

    let selected = list
        .iter()
        .find(|item| item.pointer("/loader/stable").and_then(Value::as_bool).unwrap_or(false))
        .or_else(|| list.first())
        .ok_or_else(|| format!("Fabric chưa hỗ trợ Minecraft {game_version}"))?;
    let loader_version = selected
        .pointer("/loader/version")
        .and_then(Value::as_str)
        .ok_or("Fabric loader response thiếu version")?;

    let profile_url = format!("https://meta.fabricmc.net/v2/versions/loader/{game_version}/{loader_version}/profile/json");
    client
        .get(profile_url)
        .header("User-Agent", USER_AGENT)
        .send()
        .await
        .map_err(|e| format!("Không tải được Fabric profile: {e}"))?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| e.to_string())
}

async fn install_assets(
    app: &tauri::AppHandle,
    client: &reqwest::Client,
    version_json: &Value,
    assets_root: &Path,
) -> Result<String, String> {
    let asset_index = version_json.get("assetIndex").ok_or("Version JSON thiếu assetIndex")?;
    let index_id = asset_index.get("id").and_then(Value::as_str).ok_or("Asset index thiếu id")?.to_string();
    let index_url = asset_index.get("url").and_then(Value::as_str).ok_or("Asset index thiếu url")?;
    let index_sha1 = asset_index.get("sha1").and_then(Value::as_str);
    let index_path = assets_root.join("indexes").join(format!("{index_id}.json"));
    ensure_download(client, index_url, &index_path, index_sha1, None).await?;
    let index_bytes = tokio::fs::read(&index_path).await.map_err(|e| e.to_string())?;
    let index_json: Value = serde_json::from_slice(&index_bytes).map_err(|e| e.to_string())?;
    let objects = index_json.get("objects").and_then(Value::as_object).ok_or("Asset index thiếu objects")?;

    emit_progress(app, "assets", format!("Đang kiểm tra {} game assets...", objects.len()), 28);
    let jobs: Vec<(String, u64)> = objects
        .values()
        .filter_map(|obj| Some((obj.get("hash")?.as_str()?.to_string(), obj.get("size").and_then(Value::as_u64).unwrap_or(0))))
        .collect();

    let assets_root = assets_root.to_path_buf();
    let results = stream::iter(jobs.into_iter().map(|(hash, size)| {
        let client = client.clone();
        let assets_root = assets_root.clone();
        async move {
            let prefix = hash.get(0..2).ok_or("Asset hash không hợp lệ")?;
            let path = assets_root.join("objects").join(prefix).join(&hash);
            let url = format!("https://resources.download.minecraft.net/{prefix}/{hash}");
            ensure_download(&client, &url, &path, Some(&hash), if size > 0 { Some(size) } else { None }).await
        }
    }))
    .buffer_unordered(32)
    .collect::<Vec<_>>()
    .await;

    for result in results {
        result?;
    }
    Ok(index_id)
}

async fn install_vanilla_libraries(
    app: &tauri::AppHandle,
    client: &reqwest::Client,
    version_json: &Value,
    libraries_root: &Path,
    natives_dir: &Path,
) -> Result<Vec<PathBuf>, String> {
    let libraries = version_json.get("libraries").and_then(Value::as_array).ok_or("Version JSON thiếu libraries")?;
    emit_progress(app, "libraries", format!("Đang cài {} Minecraft libraries...", libraries.len()), 42);
    tokio::fs::create_dir_all(natives_dir).await.map_err(|e| e.to_string())?;
    let mut classpath = Vec::new();

    for lib in libraries {
        if !rules_allow(lib.get("rules")) {
            continue;
        }
        let downloads = lib.get("downloads");
        if let Some(artifact) = downloads.and_then(|d| d.get("artifact")) {
            if let (Some(path), Some(url)) = (artifact.get("path").and_then(Value::as_str), artifact.get("url").and_then(Value::as_str)) {
                let target = libraries_root.join(path);
                ensure_download(client, url, &target, artifact.get("sha1").and_then(Value::as_str), artifact.get("size").and_then(Value::as_u64)).await?;
                classpath.push(target);
            }
        } else if let Some(name) = lib.get("name").and_then(Value::as_str) {
            let path = maven_path(name)?;
            let base = lib.get("url").and_then(Value::as_str).unwrap_or("https://libraries.minecraft.net/");
            let url = format!("{}{}", base.trim_end_matches('/').to_string() + "/", path);
            let target = libraries_root.join(&path);
            ensure_download(client, &url, &target, None, None).await?;
            classpath.push(target);
        }

        if cfg!(target_os = "windows") {
            if let Some(template) = lib.pointer("/natives/windows").and_then(Value::as_str) {
                let arch = if cfg!(target_arch = "x86") { "32" } else { "64" };
                let classifier = template.replace("${arch}", arch);
                if let Some(native) = downloads
                    .and_then(|d| d.get("classifiers"))
                    .and_then(|c| c.get(&classifier))
                {
                    if let (Some(path), Some(url)) = (native.get("path").and_then(Value::as_str), native.get("url").and_then(Value::as_str)) {
                        let target = libraries_root.join(path);
                        ensure_download(client, url, &target, native.get("sha1").and_then(Value::as_str), native.get("size").and_then(Value::as_u64)).await?;
                        let excludes = lib
                            .pointer("/extract/exclude")
                            .and_then(Value::as_array)
                            .map(|arr| arr.iter().filter_map(Value::as_str).map(str::to_string).collect::<Vec<_>>())
                            .unwrap_or_else(|| vec!["META-INF/".into()]);
                        let target_clone = target.clone();
                        let natives_clone = natives_dir.to_path_buf();
                        tokio::task::spawn_blocking(move || extract_zip_file(&target_clone, &natives_clone, &excludes))
                            .await
                            .map_err(|e| e.to_string())??;
                    }
                }
            }
        }
    }
    Ok(classpath)
}

async fn install_fabric_libraries(
    client: &reqwest::Client,
    fabric_profile: &Value,
    libraries_root: &Path,
) -> Result<Vec<PathBuf>, String> {
    let mut classpath = Vec::new();
    let libraries = fabric_profile.get("libraries").and_then(Value::as_array).cloned().unwrap_or_default();
    for lib in libraries {
        if !rules_allow(lib.get("rules")) {
            continue;
        }
        let name = lib.get("name").and_then(Value::as_str).ok_or("Fabric library thiếu name")?;
        let path = maven_path(name)?;
        let base = lib.get("url").and_then(Value::as_str).unwrap_or("https://maven.fabricmc.net/");
        let url = format!("{}/{}", base.trim_end_matches('/'), path);
        let target = libraries_root.join(&path);
        ensure_download(client, &url, &target, None, None).await?;
        classpath.push(target);
    }
    Ok(classpath)
}

fn substitute(input: &str, vars: &HashMap<&str, String>) -> String {
    let mut out = input.to_string();
    for (key, value) in vars {
        out = out.replace(&format!("${{{key}}}"), value);
    }
    out
}

fn collect_argument_list(value: Option<&Value>, vars: &HashMap<&str, String>) -> Vec<String> {
    let mut result = Vec::new();
    let Some(items) = value.and_then(Value::as_array) else { return result };
    for item in items {
        if let Some(text) = item.as_str() {
            result.push(substitute(text, vars));
            continue;
        }
        if !rules_allow(item.get("rules")) {
            continue;
        }
        if let Some(v) = item.get("value") {
            if let Some(text) = v.as_str() {
                result.push(substitute(text, vars));
            } else if let Some(arr) = v.as_array() {
                for text in arr.iter().filter_map(Value::as_str) {
                    result.push(substitute(text, vars));
                }
            }
        }
    }
    result
}

async fn install_logging_config(client: &reqwest::Client, version_json: &Value, shared_root: &Path) -> Result<Option<String>, String> {
    let Some(client_log) = version_json.pointer("/logging/client") else { return Ok(None) };
    let Some(file) = client_log.get("file") else { return Ok(None) };
    let Some(id) = file.get("id").and_then(Value::as_str) else { return Ok(None) };
    let Some(url) = file.get("url").and_then(Value::as_str) else { return Ok(None) };
    let path = shared_root.join("log_configs").join(id);
    ensure_download(client, url, &path, file.get("sha1").and_then(Value::as_str), file.get("size").and_then(Value::as_u64)).await?;
    let argument = client_log.get("argument").and_then(Value::as_str).unwrap_or("-Dlog4j.configurationFile=${path}");
    Ok(Some(argument.replace("${path}", &path.to_string_lossy())))
}

async fn prepare_minecraft_install(
    app: &tauri::AppHandle,
    profile_id: &str,
    game_version: &str,
    loader: &str,
) -> Result<(Value, Option<Value>, Vec<PathBuf>, PathBuf, String), String> {
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::limited(10))
        .build()
        .map_err(|e| e.to_string())?;
    let shared = shared_game_root()?;
    let libraries_root = shared.join("libraries");
    let assets_root = shared.join("assets");
    let versions_root = shared.join("versions");
    let profile_dir = profile_root(profile_id)?;
    let natives_dir = profile_dir.join("natives").join(format!("{}-{}", safe_segment(game_version), safe_segment(loader)));
    tokio::fs::create_dir_all(&profile_dir).await.map_err(|e| e.to_string())?;

    emit_progress(app, "metadata", format!("Đang đọc metadata Minecraft {game_version}..."), 14);
    let version_json = get_vanilla_version_json(&client, game_version).await?;
    let fabric_profile = if loader.eq_ignore_ascii_case("fabric") {
        emit_progress(app, "fabric", "Đang cấu hình Fabric Loader...", 19);
        Some(get_fabric_profile(&client, game_version).await?)
    } else if loader.eq_ignore_ascii_case("vanilla") {
        None
    } else {
        return Err(format!("Release Candidate hiện chạy thật với Vanilla và Fabric. Loader {loader} sẽ được bật ở bản kế tiếp."));
    };

    emit_progress(app, "client", "Đang kiểm tra Minecraft client...", 23);
    let client_download = version_json.pointer("/downloads/client").ok_or("Version JSON thiếu client download")?;
    let client_url = client_download.get("url").and_then(Value::as_str).ok_or("Client download thiếu URL")?;
    let client_jar = versions_root.join(game_version).join(format!("{game_version}.jar"));
    ensure_download(&client, client_url, &client_jar, client_download.get("sha1").and_then(Value::as_str), client_download.get("size").and_then(Value::as_u64)).await?;

    let asset_index_id = install_assets(app, &client, &version_json, &assets_root).await?;
    if natives_dir.exists() {
        let _ = tokio::fs::remove_dir_all(&natives_dir).await;
    }
    tokio::fs::create_dir_all(&natives_dir).await.map_err(|e| e.to_string())?;
    let mut classpath = install_vanilla_libraries(app, &client, &version_json, &libraries_root, &natives_dir).await?;
    if let Some(profile) = &fabric_profile {
        emit_progress(app, "fabric", "Đang cài Fabric libraries...", 55);
        classpath.extend(install_fabric_libraries(&client, profile, &libraries_root).await?);
    }
    classpath.push(client_jar);
    let _ = install_logging_config(&client, &version_json, &shared).await?;

    Ok((version_json, fabric_profile, classpath, natives_dir, asset_index_id))
}

fn spawn_console_reader<R: Read + Send + 'static>(
    reader: R,
    app: tauri::AppHandle,
    profile_id: String,
    stream_name: &'static str,
    log_file: Arc<Mutex<File>>,
) {
    std::thread::spawn(move || {
        let buffered = BufReader::new(reader);
        for line in buffered.lines().map_while(Result::ok) {
            let event = GameConsoleLine {
                profile_id: profile_id.clone(),
                stream: stream_name.into(),
                timestamp_ms: now_millis(),
                line: line.clone(),
            };
            if let Ok(mut file) = log_file.lock() {
                let _ = writeln!(file, "[{}][{}] {}", event.timestamp_ms, stream_name, line);
                let _ = file.flush();
            }
            let _ = app.emit("game-console-line", event);
        }
    });
}

#[cfg(target_os = "windows")]
fn process_exists(pid: u32) -> bool {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x08000000;
    let filter = format!("PID eq {pid}");
    Command::new("tasklist")
        .args(["/FI", filter.as_str(), "/FO", "CSV", "/NH"])
        .creation_flags(CREATE_NO_WINDOW)
        .output()
        .ok()
        .map(|output| {
            let text = String::from_utf8_lossy(&output.stdout);
            !text.contains("No tasks are running") && text.contains(&pid.to_string())
        })
        .unwrap_or(false)
}

#[cfg(not(target_os = "windows"))]
fn process_exists(_pid: u32) -> bool { false }

#[tauri::command]
async fn get_game_status(profile_id: String) -> Result<GameProcessStatus, String> {
    if let Ok(states) = game_states().lock() {
        if let Some(status) = states.get(&profile_id).cloned() {
            if status.state == "running" {
                if let Some(pid) = status.pid {
                    if process_exists(pid) {
                        return Ok(status);
                    }
                }
            } else {
                return Ok(status);
            }
        }
    }

    let pid_path = profile_root(&profile_id)?.join(".axolot").join("game.pid");
    if let Ok(text) = std::fs::read_to_string(&pid_path) {
        if let Ok(pid) = text.trim().parse::<u32>() {
            if process_exists(pid) {
                return Ok(GameProcessStatus {
                    profile_id,
                    state: "running".into(),
                    pid: Some(pid),
                    exit_code: None,
                    message: format!("Minecraft đang chạy • PID {pid}"),
                });
            }
        }
    }

    Ok(GameProcessStatus {
        profile_id,
        state: "stopped".into(),
        pid: None,
        exit_code: None,
        message: "Minecraft chưa chạy.".into(),
    })
}

#[tauri::command]
async fn read_game_console(profile_id: String) -> Result<String, String> {
    let path = profile_root(&profile_id)?.join("logs").join("axolot-console.log");
    let text = tokio::fs::read_to_string(path).await.unwrap_or_else(|_| "Console chưa có dữ liệu. Hãy chạy Minecraft trước.".into());
    let mut lines: Vec<&str> = text.lines().rev().take(1200).collect();
    lines.reverse();
    Ok(lines.join("\n"))
}

#[tauri::command]
async fn read_crash_report(profile_id: String) -> Result<CrashReport, String> {
    let cache = profile_root(&profile_id)?.join("logs").join("last-crash.json");
    if let Ok(text) = tokio::fs::read_to_string(&cache).await {
        if let Ok(report) = serde_json::from_str::<CrashReport>(&text) {
            return Ok(report);
        }
    }
    Ok(build_crash_report(&profile_id, None))
}

#[tauri::command]
async fn launch_profile(
    app: tauri::AppHandle,
    profile_id: String,
    profile_name: String,
    username: String,
    account_id: Option<String>,
    account_kind: Option<String>,
    game_version: String,
    loader: String,
    ram_gb: f64,
    server_address: Option<String>,
) -> Result<LaunchResult, String> {
    if account_kind.as_deref() != Some("microsoft") && (username.len() < 3 || username.len() > 16 || !username.chars().all(|c| c.is_ascii_alphanumeric() || c == '_')) {
        return Err("Tên Minecraft phải 3–16 ký tự và chỉ gồm chữ, số, dấu _.".into());
    }
    if !(2.0..=32.0).contains(&ram_gb) {
        return Err("RAM profile phải từ 2 đến 32 GB.".into());
    }
    if get_game_status(profile_id.clone()).await?.state == "running" {
        return Err("Minecraft của profile này đang chạy. Hãy đóng game trước khi mở thêm instance.".into());
    }

    emit_progress(&app, "start", format!("Chuẩn bị {profile_name}..."), 2);
    let javaw = ensure_java_runtime(&app, &game_version).await?;
    let (version_json, fabric_profile, classpath, natives_dir, asset_index_id) =
        prepare_minecraft_install(&app, &profile_id, &game_version, &loader).await?;

    let shared = shared_game_root()?;
    let assets_root = shared.join("assets");
    let libraries_root = shared.join("libraries");
    let game_dir = profile_root(&profile_id)?;
    tokio::fs::create_dir_all(game_dir.join("mods")).await.map_err(|e| e.to_string())?;
    tokio::fs::create_dir_all(game_dir.join("logs")).await.map_err(|e| e.to_string())?;

    let classpath_sep = if cfg!(target_os = "windows") { ";" } else { ":" };
    let classpath_text = classpath.iter().map(|p| p.to_string_lossy().to_string()).collect::<Vec<_>>().join(classpath_sep);

    let (auth_name, auth_uuid, auth_token, user_type, auth_xuid, auth_client_id) = if account_kind.as_deref() == Some("microsoft") {
        let id = account_id.as_deref().ok_or("Microsoft account id is missing")?;
        let session = microsoft_sessions().lock().map_err(|_| "Microsoft session store unavailable")?
            .get(id).cloned().ok_or("Microsoft session expired or is not signed in. Open Accounts and sign in again.")?;
        if session.expires_at_ms <= now_millis() {
            return Err("Microsoft session expired. Open Accounts and sign in again.".into());
        }
        (session.username, session.uuid, session.access_token, "msa".to_string(), session.xuid, session.client_id)
    } else {
        (username.clone(), offline_uuid(&username), "0".into(), "legacy".into(), "".into(), "".into())
    };
    let version_type = version_json.get("type").and_then(Value::as_str).unwrap_or("release").to_string();
    let version_name = if let Some(fabric) = &fabric_profile {
        fabric.get("id").and_then(Value::as_str).unwrap_or(&game_version).to_string()
    } else {
        game_version.clone()
    };

    let mut vars: HashMap<&str, String> = HashMap::new();
    vars.insert("auth_player_name", auth_name.clone());
    vars.insert("version_name", version_name.clone());
    vars.insert("game_directory", game_dir.to_string_lossy().to_string());
    vars.insert("assets_root", assets_root.to_string_lossy().to_string());
    vars.insert("assets_index_name", asset_index_id.clone());
    vars.insert("auth_uuid", auth_uuid);
    vars.insert("auth_access_token", auth_token);
    vars.insert("clientid", auth_client_id);
    vars.insert("auth_xuid", auth_xuid);
    vars.insert("user_type", user_type);
    vars.insert("version_type", version_type);
    vars.insert("natives_directory", natives_dir.to_string_lossy().to_string());
    vars.insert("launcher_name", "AxolotClient".into());
    vars.insert("launcher_version", "0.13.0".into());
    vars.insert("classpath", classpath_text.clone());
    vars.insert("classpath_separator", classpath_sep.into());
    vars.insert("library_directory", libraries_root.to_string_lossy().to_string());

    let mut jvm_args = collect_argument_list(version_json.pointer("/arguments/jvm"), &vars);
    if let Some(fabric) = &fabric_profile {
        jvm_args.extend(collect_argument_list(fabric.pointer("/arguments/jvm"), &vars));
    }
    jvm_args.retain(|arg| !arg.starts_with("-Xmx") && !arg.starts_with("-Xms"));
    jvm_args.insert(0, format!("-Xmx{}M", (ram_gb * 1024.0).round() as u32));
    jvm_args.insert(0, "-Xms512M".into());
    jvm_args.push("-Dlauncher.brand=AxolotClient".into());
    jvm_args.push("-Dlauncher.version=0.13.0".into());
    if !jvm_args.iter().any(|a| a == "-cp" || a == "-classpath") {
        jvm_args.push("-Djava.library.path=${natives_directory}".replace("${natives_directory}", &natives_dir.to_string_lossy()));
        jvm_args.push("-cp".into());
        jvm_args.push(classpath_text.clone());
    }

    let client = reqwest::Client::new();
    if let Some(log_arg) = install_logging_config(&client, &version_json, &shared).await? {
        jvm_args.push(log_arg);
    }

    let main_class = fabric_profile
        .as_ref()
        .and_then(|v| v.get("mainClass"))
        .and_then(Value::as_str)
        .or_else(|| version_json.get("mainClass").and_then(Value::as_str))
        .ok_or("Không tìm thấy Minecraft mainClass")?
        .to_string();

    let mut game_args = if version_json.pointer("/arguments/game").is_some() {
        collect_argument_list(version_json.pointer("/arguments/game"), &vars)
    } else {
        version_json
            .get("minecraftArguments")
            .and_then(Value::as_str)
            .map(|text| text.split_whitespace().map(|s| substitute(s, &vars)).collect())
            .unwrap_or_else(Vec::new)
    };
    if let Some(fabric) = &fabric_profile {
        game_args.extend(collect_argument_list(fabric.pointer("/arguments/game"), &vars));
    }

    if let Some(server) = server_address.filter(|s| !s.trim().is_empty()) {
        if version_parts(&game_version).1 >= 20 {
            game_args.push("--quickPlayMultiplayer".into());
            game_args.push(server);
        } else {
            let mut parts = server.split(':');
            if let Some(host) = parts.next() {
                game_args.push("--server".into());
                game_args.push(host.to_string());
            }
            if let Some(port) = parts.next() {
                game_args.push("--port".into());
                game_args.push(port.to_string());
            }
        }
    }

    emit_progress(&app, "launch", "Đang mở Minecraft...", 92);
    let logs_dir = game_dir.join("logs");
    std::fs::create_dir_all(&logs_dir).map_err(|e| e.to_string())?;
    let console_path = logs_dir.join("axolot-console.log");
    let console_file = OpenOptions::new().create(true).append(true).open(&console_path).map_err(|e| e.to_string())?;
    let shared_console = Arc::new(Mutex::new(console_file));

    let mut command = Command::new(&javaw);
    command.args(&jvm_args).arg(&main_class).args(&game_args).current_dir(&game_dir);
    command.stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped());

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        command.creation_flags(CREATE_NO_WINDOW);
    }

    let mut child = command.spawn().map_err(|e| format!("Không thể mở Minecraft: {e}"))?;
    let pid = child.id();
    let axolot_dir = game_dir.join(".axolot");
    std::fs::create_dir_all(&axolot_dir).map_err(|e| e.to_string())?;
    let _ = std::fs::write(axolot_dir.join("game.pid"), pid.to_string());

    set_game_state(&app, GameProcessStatus {
        profile_id: profile_id.clone(),
        state: "running".into(),
        pid: Some(pid),
        exit_code: None,
        message: format!("Minecraft đang chạy • PID {pid}"),
    });

    if let Some(stdout) = child.stdout.take() {
        spawn_console_reader(stdout, app.clone(), profile_id.clone(), "stdout", Arc::clone(&shared_console));
    }
    if let Some(stderr) = child.stderr.take() {
        spawn_console_reader(stderr, app.clone(), profile_id.clone(), "stderr", Arc::clone(&shared_console));
    }

    let wait_app = app.clone();
    let wait_profile_id = profile_id.clone();
    let wait_game_dir = game_dir.clone();
    std::thread::spawn(move || {
        let wait_result = child.wait();
        let _ = std::fs::remove_file(wait_game_dir.join(".axolot").join("game.pid"));
        match wait_result {
            Ok(exit) if exit.success() => {
                set_game_state(&wait_app, GameProcessStatus {
                    profile_id: wait_profile_id.clone(),
                    state: "stopped".into(),
                    pid: None,
                    exit_code: exit.code(),
                    message: "Minecraft đã đóng bình thường.".into(),
                });
            }
            Ok(exit) => {
                let code = exit.code();
                let report = build_crash_report(&wait_profile_id, code);
                if let Ok(json) = serde_json::to_string_pretty(&report) {
                    let _ = std::fs::write(wait_game_dir.join("logs").join("last-crash.json"), json);
                }
                set_game_state(&wait_app, GameProcessStatus {
                    profile_id: wait_profile_id.clone(),
                    state: "crashed".into(),
                    pid: None,
                    exit_code: code,
                    message: report.summary.clone(),
                });
                let _ = wait_app.emit("game-crash", report);
            }
            Err(error) => {
                let report = CrashReport {
                    profile_id: wait_profile_id.clone(),
                    exit_code: None,
                    summary: format!("Không thể theo dõi tiến trình Minecraft: {error}"),
                    source: "process-monitor".into(),
                    lines: vec![CrashLine { number: 1, level: "error".into(), text: error.to_string() }],
                    suspicious: vec![CrashLine { number: 1, level: "error".into(), text: error.to_string() }],
                };
                set_game_state(&wait_app, GameProcessStatus {
                    profile_id: wait_profile_id.clone(),
                    state: "crashed".into(),
                    pid: None,
                    exit_code: None,
                    message: report.summary.clone(),
                });
                let _ = wait_app.emit("game-crash", report);
            }
        }
    });

    emit_progress(&app, "done", format!("Minecraft đang chạy • PID {pid}"), 100);
    Ok(LaunchResult {
        pid,
        profile_dir: game_dir.to_string_lossy().to_string(),
        java_runtime: javaw.to_string_lossy().to_string(),
        message: format!("Đã mở {profile_name} • Minecraft {game_version} • {loader}"),
    })
}

#[tauri::command]
async fn open_profile_folder(profile_id: String) -> Result<String, String> {
    let root = profile_root(&profile_id)?;
    tokio::fs::create_dir_all(&root).await.map_err(|e| e.to_string())?;
    #[cfg(target_os = "windows")]
    Command::new("explorer.exe").arg(&root).spawn().map_err(|e| e.to_string())?;
    Ok(root.to_string_lossy().to_string())
}

#[tauri::command]
async fn read_game_log(profile_id: String) -> Result<String, String> {
    let path = profile_root(&profile_id)?.join("logs").join("latest.log");
    let text = tokio::fs::read_to_string(path).await.unwrap_or_else(|_| "Chưa có latest.log cho profile này.".into());
    let mut lines: Vec<&str> = text.lines().rev().take(350).collect();
    lines.reverse();
    Ok(lines.join("\n"))
}

#[tauri::command]
async fn sync_manifest(manifest_url: String) -> Result<String, String> {
    if manifest_url.contains("example.com") {
        return Ok("Updater CDN chưa được cấu hình. Game launcher vẫn hoạt động độc lập.".into());
    }

    let manifest: ClientManifest = reqwest::get(&manifest_url)
        .await
        .map_err(|e| format!("Không tải được manifest: {e}"))?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| format!("Manifest không hợp lệ: {e}"))?;

    let root = app_root()?.join("client-files");
    tokio::fs::create_dir_all(&root).await.map_err(|e| e.to_string())?;
    let client = reqwest::Client::new();
    let mut changed = 0usize;

    for item in &manifest.files {
        let dest = root.join(&item.path);
        let mut needs_download = true;
        if let Ok(bytes) = tokio::fs::read(&dest).await {
            let hash = format!("{:x}", Sha256::digest(&bytes));
            needs_download = hash != item.sha256.to_lowercase();
        }
        if needs_download {
            if let Some(parent) = dest.parent() {
                tokio::fs::create_dir_all(parent).await.map_err(|e| e.to_string())?;
            }
            let bytes = download_bytes(&client, &item.url).await?;
            let hash = format!("{:x}", Sha256::digest(&bytes));
            if hash != item.sha256.to_lowercase() {
                return Err(format!("SHA-256 sai: {}", item.path));
            }
            tokio::fs::write(&dest, bytes).await.map_err(|e| e.to_string())?;
            changed += 1;
        }
    }
    Ok(format!("Client {} đã sẵn sàng • {} file cập nhật", manifest.client_version, changed))
}

#[tauri::command]
async fn list_profile_mods(profile_id: String) -> Result<Vec<ModFileEntry>, String> {
    let dir = mods_dir(&profile_id)?;
    tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
    let mut reader = tokio::fs::read_dir(&dir).await.map_err(|e| e.to_string())?;
    let mut result = Vec::new();
    while let Some(entry) = reader.next_entry().await.map_err(|e| e.to_string())? {
        let metadata = entry.metadata().await.map_err(|e| e.to_string())?;
        if !metadata.is_file() { continue; }
        let name = entry.file_name().to_string_lossy().to_string();
        let enabled = !name.ends_with(".disabled");
        if name.ends_with(".jar") || name.ends_with(".jar.disabled") {
            result.push(ModFileEntry { name, enabled, size_bytes: metadata.len() });
        }
    }
    result.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Ok(result)
}

#[tauri::command]
async fn import_local_mod(profile_id: String, file_name: String, bytes: Vec<u8>) -> Result<String, String> {
    let file_name = safe_file_name(&file_name)?;
    if !file_name.to_lowercase().ends_with(".jar") {
        return Err("Axolot Client chỉ nhận file mod .jar".into());
    }
    let dir = mods_dir(&profile_id)?;
    tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
    tokio::fs::write(dir.join(&file_name), bytes).await.map_err(|e| e.to_string())?;
    Ok(format!("Đã thêm {} vào profile", file_name))
}

#[tauri::command]
async fn set_mod_enabled(profile_id: String, file_name: String, enabled: bool) -> Result<String, String> {
    let dir = mods_dir(&profile_id)?;
    let file_name = safe_file_name(&file_name)?;
    let source = dir.join(&file_name);
    if enabled {
        if !file_name.ends_with(".disabled") { return Ok(file_name); }
        let target_name = file_name.trim_end_matches(".disabled").to_string();
        tokio::fs::rename(source, dir.join(&target_name)).await.map_err(|e| e.to_string())?;
        Ok(target_name)
    } else {
        if file_name.ends_with(".disabled") { return Ok(file_name); }
        let target_name = format!("{}.disabled", file_name);
        tokio::fs::rename(source, dir.join(&target_name)).await.map_err(|e| e.to_string())?;
        Ok(target_name)
    }
}

#[tauri::command]
async fn remove_mod(profile_id: String, file_name: String) -> Result<String, String> {
    let dir = mods_dir(&profile_id)?;
    let file_name = safe_file_name(&file_name)?;
    tokio::fs::remove_file(dir.join(&file_name)).await.map_err(|e| e.to_string())?;
    Ok(format!("Đã xoá {}", file_name))
}

#[tauri::command]
async fn search_modrinth(query: String, project_type: String, game_version: String, loader: String) -> Result<Vec<ModrinthHit>, String> {
    let project_type = if project_type == "modpack" { "modpack" } else { "mod" };
    let loader = loader.to_lowercase();
    let mut facet_groups = vec![format!("[\"project_type:{}\"]", project_type)];
    if !game_version.trim().is_empty() { facet_groups.push(format!("[\"versions:{}\"]", game_version)); }
    if project_type == "mod" && loader != "vanilla" && !loader.is_empty() { facet_groups.push(format!("[\"categories:{}\"]", loader)); }
    let facets = format!("[{}]", facet_groups.join(","));

    let client = reqwest::Client::new();
    let response: ModrinthSearchResponse = client
        .get("https://api.modrinth.com/v2/search")
        .header("User-Agent", USER_AGENT)
        .query(&[("query", query.as_str()), ("facets", facets.as_str()), ("limit", "30"), ("index", if query.trim().is_empty() { "downloads" } else { "relevance" })])
        .send().await.map_err(|e| format!("Không kết nối được Modrinth: {e}"))?
        .error_for_status().map_err(|e| format!("Modrinth trả về lỗi: {e}"))?
        .json().await.map_err(|e| format!("Không đọc được dữ liệu Modrinth: {e}"))?;
    Ok(response.hits)
}

async fn install_modrinth_mod_for_profile(client: &reqwest::Client, profile_id: &str, project_id: &str, game_version: &str, loader: &str) -> Result<String, String> {
    let versions_url = format!("https://api.modrinth.com/v2/project/{}/version", project_id);
    let game_versions = serde_json::to_string(&vec![game_version]).map_err(|e| e.to_string())?;
    let loader_lower = loader.to_lowercase();
    let loaders = serde_json::to_string(&vec![loader_lower]).map_err(|e| e.to_string())?;
    let versions: Vec<ModrinthVersion> = client.get(&versions_url).header("User-Agent", USER_AGENT)
        .query(&[("game_versions", game_versions.as_str()), ("loaders", loaders.as_str())])
        .send().await.map_err(|e| format!("{}: {e}", project_id))?
        .error_for_status().map_err(|e| format!("{}: {e}", project_id))?
        .json().await.map_err(|e| format!("{}: {e}", project_id))?;
    let version = versions.first().ok_or_else(|| format!("{} chưa có bản tương thích {} / {}", project_id, game_version, loader))?;
    let file = version.files.iter().find(|f| f.primary).or_else(|| version.files.first()).ok_or_else(|| format!("{} không có file tải", project_id))?;
    let bytes = download_bytes(client, &file.url).await?;
    let file_name = safe_file_name(&file.filename)?;
    let dir = mods_dir(profile_id)?;
    tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
    tokio::fs::write(dir.join(&file_name), bytes).await.map_err(|e| e.to_string())?;
    Ok(file_name)
}

#[tauri::command]
async fn install_modrinth_project(profile_id: String, project_id: String, project_type: String, game_version: String, loader: String) -> Result<String, String> {
    if project_type != "modpack" {
        let client = reqwest::Client::new();
        return install_modrinth_mod_for_profile(&client, &profile_id, &project_id, &game_version, &loader).await.map(|f| format!("Đã cài mod {f}"));
    }

    let client = reqwest::Client::new();
    let versions_url = format!("https://api.modrinth.com/v2/project/{}/version", project_id);
    let game_versions = serde_json::to_string(&vec![game_version]).map_err(|e| e.to_string())?;
    let loader_lower = loader.to_lowercase();
    let loaders = serde_json::to_string(&vec![loader_lower]).map_err(|e| e.to_string())?;
    let versions: Vec<ModrinthVersion> = client.get(&versions_url).header("User-Agent", USER_AGENT)
        .query(&[("game_versions", game_versions.as_str()), ("loaders", loaders.as_str())])
        .send().await.map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?
        .json().await.map_err(|e| e.to_string())?;
    let version = versions.first().ok_or("Không có modpack tương thích")?;
    let file = version.files.iter().find(|f| f.primary).or_else(|| version.files.first()).ok_or("Modpack không có file")?;
    let bytes = download_bytes(&client, &file.url).await?;
    let file_name = safe_file_name(&file.filename)?;
    let packs = modpacks_dir(&profile_id)?;
    tokio::fs::create_dir_all(&packs).await.map_err(|e| e.to_string())?;
    let archive_path = packs.join(&file_name);
    tokio::fs::write(&archive_path, &bytes).await.map_err(|e| e.to_string())?;

    let root = profile_root(&profile_id)?;
    let archive_for_index = archive_path.clone();
    let index = tokio::task::spawn_blocking(move || parse_mrpack_index(&archive_for_index))
        .await.map_err(|e| e.to_string())??;

    let mut downloaded = 0usize;
    for entry in index.files {
        let Some(url) = entry.downloads.first() else { continue };
        let relative = safe_relative_path(&entry.path)?;
        let target = root.join(relative);
        let sha1 = entry.hashes.get("sha1").map(String::as_str);
        ensure_download(&client, url, &target, sha1, if entry.file_size > 0 { Some(entry.file_size) } else { None }).await?;
        downloaded += 1;
    }

    let archive_clone = archive_path.clone();
    let root_clone = root.clone();
    tokio::task::spawn_blocking(move || -> Result<(), String> {
        extract_archive_prefix(&archive_clone, &root_clone, "overrides")?;
        extract_archive_prefix(&archive_clone, &root_clone, "client-overrides")?;
        Ok(())
    }).await.map_err(|e| e.to_string())??;

    Ok(format!("Đã cài modpack {file_name} • {downloaded} dependency file(s) + overrides."))
}


fn curseforge_loader_type(loader: &str) -> Option<u32> {
    match loader.to_ascii_lowercase().as_str() {
        "forge" => Some(1),
        "fabric" => Some(4),
        "quilt" => Some(5),
        "neoforge" => Some(6),
        _ => None,
    }
}

async fn curseforge_proxy_json(
    client: &reqwest::Client,
    path: &str,
    params: &[(String, String)],
) -> Result<Value, String> {
    let mut query = vec![("path".to_string(), path.to_string())];
    query.extend_from_slice(params);
    client.get(AXOLOT_CURSEFORGE_PROXY)
        .header("Accept", "application/json")
        .header("User-Agent", USER_AGENT)
        .query(&query)
        .send().await.map_err(|e| format!("Could not connect to Axolot CurseForge proxy: {e}"))?
        .error_for_status().map_err(|e| format!("Axolot CurseForge proxy returned an error: {e}"))?
        .json().await.map_err(|e| format!("Invalid CurseForge proxy response: {e}"))
}

async fn curseforge_file_info(
    client: &reqwest::Client,
    mod_id: u64,
    file_id: u64,
) -> Result<(String, String), String> {
    let path = format!("/v1/mods/{mod_id}/files/{file_id}");
    let response = curseforge_proxy_json(client, &path, &[]).await?;
    let data = response.get("data").ok_or("CurseForge file response is missing data")?;
    let file_name = data.get("fileName").and_then(Value::as_str).ok_or("CurseForge file has no fileName")?.to_string();
    if let Some(download) = data.get("downloadUrl").and_then(Value::as_str).filter(|s| !s.is_empty()) {
        return Ok((download.to_string(), file_name));
    }
    let download_path = format!("/v1/mods/{mod_id}/files/{file_id}/download-url");
    let download_response = curseforge_proxy_json(client, &download_path, &[]).await?;
    let download_url = download_response.get("data").and_then(Value::as_str)
        .filter(|s| !s.is_empty())
        .ok_or("This CurseForge file cannot be redistributed/downloaded through the API")?;
    Ok((download_url.to_string(), file_name))
}

async fn curseforge_pick_file(
    client: &reqwest::Client,
    mod_id: u64,
    game_version: &str,
    loader: &str,
) -> Result<(u64, String, String), String> {
    let path = format!("/v1/mods/{mod_id}/files");
    let mut query: Vec<(String, String)> = vec![
        ("gameVersion".into(), game_version.to_string()),
        ("pageSize".into(), "50".into()),
    ];
    if let Some(loader_type) = curseforge_loader_type(loader) {
        query.push(("modLoaderType".into(), loader_type.to_string()));
    }
    let response = curseforge_proxy_json(client, &path, &query).await?;
    let files = response.get("data").and_then(Value::as_array).ok_or("CurseForge returned no file list")?;
    let file = files.first().ok_or_else(|| format!("No CurseForge file matches Minecraft {game_version} / {loader}"))?;
    let file_id = file.get("id").and_then(Value::as_u64).ok_or("CurseForge file id missing")?;
    let (download_url, file_name) = curseforge_file_info(client, mod_id, file_id).await?;
    Ok((file_id, download_url, file_name))
}

#[tauri::command]
async fn search_curseforge(
    query: String,
    project_type: String,
    game_version: String,
    loader: String,
) -> Result<Vec<ModrinthHit>, String> {
    let kind = if project_type == "modpack" { "modpack" } else { "mod" };
    let class_id = if kind == "modpack" { 4471 } else { 6 };
    let mut params: Vec<(String, String)> = vec![
        ("gameId".into(), "432".into()),
        ("classId".into(), class_id.to_string()),
        ("gameVersion".into(), game_version.clone()),
        ("pageSize".into(), "30".into()),
        ("sortField".into(), "2".into()),
        ("sortOrder".into(), "desc".into()),
    ];
    if !query.trim().is_empty() { params.push(("searchFilter".into(), query)); }
    if let Some(loader_type) = curseforge_loader_type(&loader) { params.push(("modLoaderType".into(), loader_type.to_string())); }

    let client = reqwest::Client::new();
    let response = curseforge_proxy_json(&client, "/v1/mods/search", &params).await?;
    let data = response.get("data").and_then(Value::as_array).ok_or("CurseForge search response is missing data")?;
    Ok(data.iter().filter_map(|item| {
        let id = item.get("id")?.as_u64()?;
        let title = item.get("name")?.as_str()?.to_string();
        let description = item.get("summary").and_then(Value::as_str).unwrap_or("").to_string();
        let icon_url = item.pointer("/logo/thumbnailUrl").and_then(Value::as_str).map(str::to_string);
        let author = item.get("authors").and_then(Value::as_array)
            .and_then(|authors| authors.first())
            .and_then(|author| author.get("name"))
            .and_then(Value::as_str).unwrap_or("CurseForge").to_string();
        let downloads = item.get("downloadCount").and_then(Value::as_u64).unwrap_or(0);
        let versions = item.get("latestFilesIndexes").and_then(Value::as_array).map(|indexes| {
            let mut values = indexes.iter().filter_map(|index| index.get("gameVersion").and_then(Value::as_str).map(str::to_string)).collect::<Vec<_>>();
            values.sort(); values.dedup(); values
        }).unwrap_or_default();
        let categories = item.get("categories").and_then(Value::as_array).map(|categories| {
            categories.iter().filter_map(|category| category.get("name").and_then(Value::as_str).map(str::to_string)).collect::<Vec<_>>()
        }).unwrap_or_default();
        Some(ModrinthHit {
            project_id: id.to_string(), title, description, icon_url: Some(icon_url).flatten(), author,
            downloads, versions, categories, project_type: kind.to_string(),
        })
    }).collect())
}

#[tauri::command]
async fn install_curseforge_project(
    profile_id: String,
    project_id: String,
    project_type: String,
    game_version: String,
    loader: String,
) -> Result<String, String> {
    let mod_id = project_id.parse::<u64>().map_err(|_| "Invalid CurseForge project id".to_string())?;
    let client = reqwest::Client::new();
    let (_file_id, download_url, file_name) = curseforge_pick_file(&client, mod_id, &game_version, &loader).await?;
    let bytes = download_bytes(&client, &download_url).await?;

    if project_type != "modpack" {
        let file_name = safe_file_name(&file_name)?;
        let dir = mods_dir(&profile_id)?;
        tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
        tokio::fs::write(dir.join(&file_name), bytes).await.map_err(|e| e.to_string())?;
        return Ok(format!("Installed CurseForge mod {file_name}"));
    }

    let packs = modpacks_dir(&profile_id)?;
    tokio::fs::create_dir_all(&packs).await.map_err(|e| e.to_string())?;
    let archive_name = safe_file_name(&file_name)?;
    let archive_path = packs.join(&archive_name);
    tokio::fs::write(&archive_path, bytes).await.map_err(|e| e.to_string())?;
    let archive_for_manifest = archive_path.clone();
    let manifest = tokio::task::spawn_blocking(move || parse_curseforge_manifest(&archive_for_manifest))
        .await.map_err(|e| e.to_string())??;

    let mods = mods_dir(&profile_id)?;
    tokio::fs::create_dir_all(&mods).await.map_err(|e| e.to_string())?;
    let mut installed = 0usize;
    for dependency in &manifest.files {
        if !dependency.required { continue; }
        let (url, dep_name) = curseforge_file_info(&client, dependency.project_id, dependency.file_id).await?;
        let dep_bytes = download_bytes(&client, &url).await?;
        let dep_name = safe_file_name(&dep_name)?;
        tokio::fs::write(mods.join(dep_name), dep_bytes).await.map_err(|e| e.to_string())?;
        installed += 1;
    }

    let root = profile_root(&profile_id)?;
    let archive_clone = archive_path.clone();
    let root_clone = root.clone();
    tokio::task::spawn_blocking(move || -> Result<(), String> {
        extract_archive_prefix(&archive_clone, &root_clone, "overrides")?;
        extract_archive_prefix(&archive_clone, &root_clone, "client-overrides")?;
        Ok(())
    }).await.map_err(|e| e.to_string())??;

    Ok(format!("Installed CurseForge modpack {archive_name} • {installed} dependency file(s) + overrides."))
}


#[tauri::command]
async fn install_optimization_pack(profile_id: String, game_version: String, loader: String, ram_gb: f64) -> Result<OptimizationPackResult, String> {
    if loader.to_lowercase() != "fabric" {
        return Ok(OptimizationPackResult { installed: Vec::new(), failed: Vec::new(), preset: "Loader compatibility mode".into(), message: "Axolot AutoBoost tự động tối ưu mạnh nhất cho Fabric. Loader này sẽ không bị chèn mod Fabric.".into() });
    }
    let preset = if ram_gb <= 3.5 { "Low-End Safe" } else if ram_gb <= 6.0 { "Balanced Smooth" } else { "Performance+" };
    let mut projects: Vec<&str> = vec!["fabric-api", "sodium", "lithium", "ferrite-core", "immediatelyfast", "entityculling", "dynamic-fps", "modmenu"];
    if ram_gb > 3.5 { projects.extend(["moreculling", "sodium-extra", "reeses-sodium-options"]); }
    if ram_gb > 6.0 { projects.extend(["fastquit", "krypton"]); }

    let dir = mods_dir(&profile_id)?;
    tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
    tokio::fs::write(dir.join("axolot-client-core-0.6.0.jar"), AXOLOT_CORE_BYTES).await.map_err(|e| format!("Không ghi được Axolot Client Core: {e}"))?;
    let client = reqwest::Client::new();
    let mut installed = vec!["Axolot Client Core 0.6.0".to_string()];
    let mut failed = Vec::new();
    for project in projects {
        match install_modrinth_mod_for_profile(&client, &profile_id, project, &game_version, &loader).await {
            Ok(file_name) => installed.push(format!("{} ({})", project, file_name)),
            Err(error) => failed.push(error),
        }
    }
    let message = if failed.is_empty() {
        format!("Axolot AutoBoost {preset} đã cài {} thành phần tối ưu.", installed.len())
    } else {
        format!("Axolot AutoBoost {preset} đã cài {} thành phần; {} mod chưa có bản tương thích.", installed.len(), failed.len())
    };
    Ok(OptimizationPackResult { installed, failed, preset: preset.into(), message })
}


fn normalize_uuid(raw: &str) -> String {
    let hex = raw.replace('-', "");
    if hex.len() == 32 {
        format!("{}-{}-{}-{}-{}", &hex[0..8], &hex[8..12], &hex[12..16], &hex[16..20], &hex[20..32])
    } else { raw.to_string() }
}

fn version_is_newer(latest: &str, current: &str) -> bool {
    fn parts(value: &str) -> Vec<u64> {
        value.trim_start_matches('v').split(|c: char| !c.is_ascii_digit())
            .filter(|x| !x.is_empty()).take(4).map(|x| x.parse().unwrap_or(0)).collect()
    }
    let a = parts(latest); let b = parts(current);
    for i in 0..a.len().max(b.len()) {
        let av = *a.get(i).unwrap_or(&0); let bv = *b.get(i).unwrap_or(&0);
        if av != bv { return av > bv; }
    }
    false
}

#[tauri::command]
async fn begin_microsoft_login(client_id: String) -> Result<MicrosoftDeviceCode, String> {
    let client_id = client_id.trim().to_string();
    if client_id.len() < 8 { return Err("Microsoft sign-in is not configured by the Axolot administrator yet.".into()); }
    let client = reqwest::Client::new();
    let response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode")
        .form(&[("client_id", client_id.as_str()), ("scope", "XboxLive.signin offline_access")])
        .send().await.map_err(|e| format!("Microsoft device login unavailable: {e}"))?;
    let status = response.status();
    let value: Value = response.json().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(value.get("error_description").and_then(Value::as_str).unwrap_or("Microsoft rejected the device login request.").to_string());
    }
    Ok(MicrosoftDeviceCode {
        device_code: value.get("device_code").and_then(Value::as_str).ok_or("Microsoft response missing device_code")?.to_string(),
        user_code: value.get("user_code").and_then(Value::as_str).ok_or("Microsoft response missing user_code")?.to_string(),
        verification_uri: value.get("verification_uri").or_else(|| value.get("verification_uri_complete")).and_then(Value::as_str).unwrap_or("https://microsoft.com/link").to_string(),
        message: value.get("message").and_then(Value::as_str).unwrap_or("Open microsoft.com/link and enter the code.").to_string(),
        expires_in: value.get("expires_in").and_then(Value::as_u64).unwrap_or(900),
        interval: value.get("interval").and_then(Value::as_u64).unwrap_or(5).max(2),
    })
}

#[tauri::command]
async fn complete_microsoft_login(app: tauri::AppHandle, client_id: String, device_code: String, expires_in: u64, interval: u64) -> Result<MicrosoftLoginResult, String> {
    let client = reqwest::Client::builder()
        .user_agent(USER_AGENT)
        .timeout(std::time::Duration::from_secs(30))
        .build()
        .map_err(|e| format!("Could not initialize Microsoft HTTP client: {e}"))?;
    emit_microsoft_progress(&app, "device", "Waiting for Microsoft authorization…", 12);
    let started = SystemTime::now();
    let mut wait = interval.max(2);
    let ms_access = loop {
        if started.elapsed().map(|x| x.as_secs()).unwrap_or(expires_in + 1) >= expires_in { return Err("Microsoft sign-in code expired. Start sign-in again.".into()); }
        tokio::time::sleep(std::time::Duration::from_secs(wait)).await;
        let response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token")
            .form(&[("grant_type", "urn:ietf:params:oauth:grant-type:device_code"), ("client_id", client_id.as_str()), ("device_code", device_code.as_str())])
            .send().await.map_err(|e| e.to_string())?;
        let status = response.status();
        let value: Value = response.json().await.map_err(|e| e.to_string())?;
        if status.is_success() {
            emit_microsoft_progress(&app, "microsoft", "Microsoft account confirmed. Connecting Xbox Live…", 32);
            break value.get("access_token").and_then(Value::as_str).ok_or("Microsoft token response missing access_token")?.to_string();
        }
        match value.get("error").and_then(Value::as_str).unwrap_or("") {
            "authorization_pending" => continue,
            "slow_down" => { wait += 5; continue; },
            "authorization_declined" => return Err("Microsoft sign-in was cancelled.".into()),
            "expired_token" => return Err("Microsoft sign-in code expired.".into()),
            other => {
                let description = value.get("error_description").and_then(Value::as_str).unwrap_or("Microsoft token exchange failed.");
                return Err(format!("Microsoft OAuth error {}: {}", if other.is_empty() { "unknown" } else { other }, description));
            },
        }
    };

    emit_microsoft_progress(&app, "xbox", "Authenticating with Xbox Live…", 42);
    let xbox_body = serde_json::json!({
        "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={ms_access}")},
        "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
    });
    let xbox: Value = client.post("https://user.auth.xboxlive.com/user/authenticate").json(&xbox_body).send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| format!("Xbox authentication failed: {e}"))?.json().await.map_err(|e| e.to_string())?;
    let xbox_token = xbox.get("Token").and_then(Value::as_str).ok_or("Xbox response missing token")?;
    emit_microsoft_progress(&app, "xsts", "Xbox Live connected. Authorizing Minecraft access…", 54);

    let xsts_body = serde_json::json!({
        "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
        "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
    });
    let xsts_response = client.post("https://xsts.auth.xboxlive.com/xsts/authorize").json(&xsts_body).send().await.map_err(|e| e.to_string())?;
    let xsts_status = xsts_response.status();
    let xsts: Value = xsts_response.json().await.map_err(|e| e.to_string())?;
    if !xsts_status.is_success() {
        let xerr = xsts.get("XErr").and_then(Value::as_u64).unwrap_or(0);
        return Err(match xerr {
            2148916233 => "This Microsoft account does not have an Xbox profile. Create one, then try again.".into(),
            2148916238 => "This Xbox account is a child account and requires family approval.".into(),
            _ => format!("Xbox XSTS authentication failed (XErr {xerr})."),
        });
    }
    let xsts_token = xsts.get("Token").and_then(Value::as_str).ok_or("XSTS response missing token")?;
    let xui = xsts.pointer("/DisplayClaims/xui/0").ok_or("XSTS response missing user claims")?;
    let uhs = xui.get("uhs").and_then(Value::as_str).ok_or("XSTS response missing user hash")?;
    let xuid = xui.get("xid").and_then(Value::as_str).unwrap_or("").to_string();
    emit_microsoft_progress(&app, "minecraft", "XSTS authorized. Signing into Minecraft Services…", 66);

    let minecraft_response = client.post("https://api.minecraftservices.com/authentication/login_with_xbox")
        .json(&serde_json::json!({"identityToken": format!("XBL3.0 x={uhs};{xsts_token}")}))
        .send().await.map_err(|e| format!("Minecraft Services network error: {e}"))?;
    let minecraft_status = minecraft_response.status();
    let minecraft_text = minecraft_response.text().await.map_err(|e| format!("Could not read Minecraft Services response: {e}"))?;
    if !minecraft_status.is_success() {
        let parsed: Value = serde_json::from_str(&minecraft_text).unwrap_or(Value::Null);
        let detail = parsed.get("errorMessage").and_then(Value::as_str)
            .or_else(|| parsed.get("error").and_then(Value::as_str))
            .or_else(|| parsed.get("message").and_then(Value::as_str))
            .unwrap_or(minecraft_text.as_str());
        let lower = detail.to_ascii_lowercase();
        if minecraft_status.as_u16() == 403 && (lower.contains("invalid app registration") || lower.contains("app registration")) {
            return Err("MC_APP_NOT_ALLOWLISTED: Microsoft authorization, Xbox Live and XSTS succeeded, but Minecraft Services returned HTTP 403 Invalid app registration. This Axolot Application (Client) ID must be approved through the Minecraft AppID registration process before Premium login can finish. No launcher-side OAuth setting can bypass this server-side allowlist.".into());
        }
        return Err(format!("Minecraft Services login failed (HTTP {}): {}", minecraft_status.as_u16(), detail.chars().take(500).collect::<String>()));
    }
    let minecraft_auth: Value = serde_json::from_str(&minecraft_text).map_err(|e| format!("Minecraft Services returned invalid JSON: {e}"))?;
    let mc_token = minecraft_auth.get("access_token").and_then(Value::as_str).ok_or("Minecraft Services response missing access token")?.to_string();
    let expires = minecraft_auth.get("expires_in").and_then(Value::as_u64).unwrap_or(86400);

    let entitlements: Value = client.get("https://api.minecraftservices.com/entitlements/mcstore").bearer_auth(&mc_token).send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| format!("Could not verify Minecraft ownership: {e}"))?.json().await.map_err(|e| e.to_string())?;
    if entitlements.get("items").and_then(Value::as_array).map(|x| x.is_empty()).unwrap_or(true) {
        return Err("This Microsoft account does not appear to own Minecraft Java Edition.".into());
    }
    emit_microsoft_progress(&app, "profile", "Ownership verified. Loading Minecraft profile…", 90);
    let profile_response = client.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(&mc_token).send().await.map_err(|e| e.to_string())?;
    if profile_response.status().as_u16() == 404 { return Err("Minecraft Java profile not found for this account.".into()); }
    let profile: Value = profile_response.error_for_status().map_err(|e| format!("Minecraft profile request failed: {e}"))?.json().await.map_err(|e| e.to_string())?;
    let username = profile.get("name").and_then(Value::as_str).ok_or("Minecraft profile missing username")?.to_string();
    let uuid = normalize_uuid(profile.get("id").and_then(Value::as_str).ok_or("Minecraft profile missing UUID")?);
    let account_id = format!("microsoft-{}", uuid.replace('-', ""));
    let expires_at_ms = now_millis() + (expires as u128 * 1000);
    let session = MicrosoftSession { account_id: account_id.clone(), username: username.clone(), uuid: uuid.clone(), xuid: xuid.clone(), access_token: mc_token, client_id, expires_at_ms };
    microsoft_sessions().lock().map_err(|_| "Microsoft session store unavailable")?.insert(account_id.clone(), session);
    emit_microsoft_progress(&app, "done", format!("Signed in as {username}."), 100);
    Ok(MicrosoftLoginResult { account_id, username, uuid, xuid, expires_at_ms })
}

#[tauri::command]
fn microsoft_session_active(account_id: String) -> bool {
    microsoft_sessions().lock().ok().and_then(|s| s.get(&account_id).cloned()).map(|s| s.expires_at_ms > now_millis()).unwrap_or(false)
}

#[tauri::command]
fn microsoft_logout(account_id: String) -> bool {
    microsoft_sessions().lock().map(|mut s| s.remove(&account_id).is_some()).unwrap_or(false)
}

#[tauri::command]
fn open_external_url(url: String) -> Result<(), String> {
    if !url.starts_with("https://") { return Err("Only HTTPS URLs can be opened.".into()); }
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        Command::new("cmd").args(["/C", "start", "", &url]).creation_flags(CREATE_NO_WINDOW).spawn().map_err(|e| e.to_string())?;
        return Ok(());
    }
    #[cfg(target_os = "macos")]
    { Command::new("open").arg(&url).spawn().map_err(|e| e.to_string())?; return Ok(()); }
    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    { Command::new("xdg-open").arg(&url).spawn().map_err(|e| e.to_string())?; return Ok(()); }
}

#[tauri::command]
async fn check_launcher_update(manifest_url: String) -> Result<LauncherUpdateStatus, String> {
    if !manifest_url.starts_with("https://") { return Err("Update manifest must use HTTPS.".into()); }
    let manifest: LauncherUpdateManifest = reqwest::Client::builder().timeout(std::time::Duration::from_secs(10)).build().map_err(|e| e.to_string())?.get(&manifest_url).header("User-Agent", USER_AGENT).send().await.map_err(|e| format!("Update server unavailable: {e}"))?
        .error_for_status().map_err(|e| format!("Update server returned an error: {e}"))?.json().await.map_err(|e| format!("Invalid update manifest: {e}"))?;
    let current = env!("CARGO_PKG_VERSION").to_string();
    Ok(LauncherUpdateStatus { current_version: current.clone(), latest_version: manifest.version.clone(), available: version_is_newer(&manifest.version, &current), download_url: manifest.download_url, sha256: manifest.sha256, notes: manifest.notes, mandatory: manifest.mandatory })
}

#[tauri::command]
async fn install_launcher_update(app: tauri::AppHandle, download_url: String, sha256: String) -> Result<String, String> {
    if !download_url.starts_with("https://") { return Err("Update download must use HTTPS.".into()); }
    let expected = sha256.trim().to_ascii_lowercase();
    if expected.len() != 64 || !expected.chars().all(|c| c.is_ascii_hexdigit()) { return Err("Update manifest has an invalid SHA-256.".into()); }
    let bytes = reqwest::Client::new().get(&download_url).header("User-Agent", USER_AGENT).send().await.map_err(|e| format!("Could not download update: {e}"))?.error_for_status().map_err(|e| e.to_string())?.bytes().await.map_err(|e| e.to_string())?;
    let actual = format!("{:x}", Sha256::digest(&bytes));
    if actual != expected { return Err(format!("Update integrity check failed. Expected {expected}, got {actual}.")); }
    let path = std::env::temp_dir().join("Axolot-Client-Update.exe");
    tokio::fs::write(&path, &bytes).await.map_err(|e| e.to_string())?;
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        Command::new(&path).arg("/S").creation_flags(CREATE_NO_WINDOW).spawn().map_err(|e| format!("Could not start updater: {e}"))?;
    }
    #[cfg(not(target_os = "windows"))]
    { return Err("Automatic installer replacement is currently enabled for Windows builds only.".into()); }
    let app_clone = app.clone();
    tauri::async_runtime::spawn(async move { tokio::time::sleep(std::time::Duration::from_millis(800)).await; app_clone.exit(0); });
    Ok("Update verified and installer started.".into())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            launch_profile,
            get_game_status,
            read_game_console,
            read_crash_report,
            open_profile_folder,
            read_game_log,
            sync_manifest,
            list_profile_mods,
            import_local_mod,
            set_mod_enabled,
            remove_mod,
            search_modrinth,
            install_modrinth_project,
            search_curseforge,
            install_curseforge_project,
            install_optimization_pack,
            begin_microsoft_login,
            complete_microsoft_login,
            microsoft_session_active,
            microsoft_logout,
            open_external_url,
            check_launcher_update,
            install_launcher_update
        ])
        .run(tauri::generate_context!())
        .expect("error while running Axolot Client");
}
