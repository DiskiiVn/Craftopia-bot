# Axolot Client 0.13.0 — Aurora

Bản nâng cấp giao diện và tiện ích dựa trên source v0.12.0 người dùng cung cấp, tích hợp bản vá Microsoft AppID v0.12.1. Nhánh v0.12.2 được kiểm tra chỉ có một phần patch chưa đầy đủ, nên không áp dụng phần backend thiếu dữ liệu.

## Điểm mới
- Giao diện Aurora: sidebar, cảnh thung lũng voxel, bảng chơi nhanh và Mission Control.
- Ba màu Mint / Violet / Amber, chế độ gọn và giảm chuyển động; tự lưu trên máy.
- Ctrl+K để tìm trang và chuyển profile; Escape đóng hộp thoại; hỗ trợ Tab.
- Lưu, tìm, đánh dấu yêu thích, sao chép và kết nối nhanh server Java.
- Chỉnh tên, RAM và profile mặc định; lịch sử ghi sau khi game mở thành công.
- Thêm nhiều tài khoản offline; giữ hỗ trợ nhiều tài khoản Microsoft có sẵn.
- Trung tâm hoạt động hiển thị trạng thái và lỗi thật.
- Giữ Modrinth / CurseForge proxy, AutoBoost, console và Crash Center.
- Không dùng địa chỉ CDN mẫu cho nút kiểm tra cập nhật.
- Cloud config có timeout 7 giây để không giữ màn hình khởi động vô hạn.

## Chạy và build Windows
Yêu cầu Node.js 22+, Rust stable, Visual Studio Build Tools với C++ desktop và Windows SDK, WebView2.

```powershell
npm ci
npm run build
npm run tauri build -- --bundles nsis
```
Installer nằm trong `src-tauri/target/release/bundle/nsis/`.
`build-windows.ps1` kiểm tra các bước trên và chép installer vào `release/`.

## Sử dụng
1. Tài khoản: thêm tài khoản Offline hoặc đăng nhập Microsoft.
2. Thư viện: tạo profile Minecraft với Fabric hoặc Vanilla, chọn phiên bản và RAM.
3. Trang chủ: chọn profile rồi Chơi Minecraft.
4. Máy chủ: nhập địa chỉ Java và bấm Vào chơi với profile đang chọn.
5. Giao diện: chọn màu, bật/tắt chuyển động và chế độ gọn.

## Giới hạn cần biết
- Đây là launcher riêng của Axolot, không bao gồm các mod/cosmetic độc quyền của Lunar Client, chat bạn bè hay hệ thống cape.
- Forge/NeoForge chưa được triển khai trong backend hiện có.
- Microsoft login vẫn phụ thuộc AppID đã được Minecraft phê duyệt và quyền sở hữu game. Tài khoản offline không truy cập được server yêu cầu xác thực bản quyền.
- Chưa bổ sung lưu refresh token vào credential vault. Phiên Microsoft từ backend hiện có có thể cần đăng nhập lại sau khi đóng launcher.
- Máy chủ hỗ trợ tên miền/IPv4 và port; chưa có hiển thị ping, số người chơi hoặc IPv6.
- AutoBoost tải mod theo phiên bản. Chưa kiểm tra thực tế mọi mod và phiên bản Minecraft.
- Profile, tài khoản và giao diện cũ giữ cùng khóa dữ liệu. Sao lưu thư mục game trước khi thay đổi mod.
- Bản UI Preview trong trình duyệt không mở Minecraft hoặc quản lý file; các thao tác này dùng bản EXE.
- Build này không tự xuất bản lên kênh cập nhật đang dùng. Installer chưa ký chứng chỉ Windows.

## Nguồn
Dùng mã nguồn đã gửi, backend Tauri/Rust và React. Hình nền SVG Aurora được tạo riêng và đóng gói cục bộ, không cần tải ảnh từ mạng.
