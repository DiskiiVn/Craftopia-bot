import postgres from "postgres";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type": "application/json",
};
const allowed = [
  /^\/v1\/mods\/search$/,
  /^\/v1\/mods\/\d+\/files$/,
  /^\/v1\/mods\/\d+\/files\/\d+$/,
  /^\/v1\/mods\/\d+\/files\/\d+\/download-url$/,
];
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "GET") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: cors });
  const incoming = new URL(req.url);
  const path = incoming.searchParams.get("path") || "";
  if (!allowed.some((re) => re.test(path))) return new Response(JSON.stringify({ error: "Unsupported CurseForge endpoint" }), { status: 400, headers: cors });
  const dbUrl = Deno.env.get("SUPABASE_DB_URL");
  if (!dbUrl) return new Response(JSON.stringify({ error: "Database unavailable" }), { status: 500, headers: cors });
  const sql = postgres(dbUrl, { prepare: false, max: 1 });
  try {
    const rows = await sql`select curseforge_api_key from axolot_private.launcher_config where id = 1 limit 1`;
    const apiKey = rows[0]?.curseforge_api_key || "";
    if (!apiKey) return new Response(JSON.stringify({ error: "CurseForge is not configured by the Axolot administrator" }), { status: 503, headers: cors });
    const target = new URL("https://api.curseforge.com" + path);
    incoming.searchParams.forEach((value, key) => { if (key !== "path") target.searchParams.append(key, value); });
    const upstream = await fetch(target, { headers: { "x-api-key": apiKey, "Accept": "application/json", "User-Agent": "AxolotClient/0.11.1" } });
    const body = await upstream.arrayBuffer();
    return new Response(body, { status: upstream.status, headers: { ...cors, "Content-Type": upstream.headers.get("content-type") || "application/json", "Cache-Control": upstream.ok ? "public, max-age=120" : "no-store" } });
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error?.message ?? error) }), { status: 500, headers: cors });
  } finally {
    await sql.end({ timeout: 1 }).catch(() => undefined);
  }
});
