import postgres from "postgres";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-axolot-admin",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json",
};
const enc = new TextEncoder();
async function sha256Hex(value: string) {
  const hash = await crypto.subtle.digest("SHA-256", enc.encode(value));
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function mask(value: string) {
  if (!value) return "";
  if (value.length <= 8) return "••••••••";
  return value.slice(0, 4) + "••••••••" + value.slice(-4);
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const dbUrl = Deno.env.get("SUPABASE_DB_URL");
  if (!dbUrl) return new Response(JSON.stringify({ error: "Database unavailable" }), { status: 500, headers: cors });
  const sql = postgres(dbUrl, { prepare: false, max: 1 });
  try {
    const body = req.method === "POST" ? await req.json().catch(() => ({})) : {};
    const token = req.headers.get("x-axolot-admin") || body?.admin_token || "";
    if (token.length < 24) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: cors });
    const rows = await sql`select microsoft_client_id, curseforge_api_key, update_manifest_url, latest_launcher_version, admin_token_sha256, updated_at from axolot_private.launcher_config where id = 1 limit 1`;
    const current = rows[0];
    if (!current || await sha256Hex(token) !== current.admin_token_sha256) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: cors });
    if (req.method === "GET") return new Response(JSON.stringify({
      microsoft_client_id: current.microsoft_client_id,
      curseforge_api_key_masked: mask(current.curseforge_api_key),
      curseforge_enabled: Boolean(current.curseforge_api_key),
      update_manifest_url: current.update_manifest_url,
      latest_launcher_version: current.latest_launcher_version,
      updated_at: current.updated_at,
    }), { headers: cors });
    if (req.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: cors });
    const nextMicrosoft = typeof body.microsoft_client_id === "string" ? body.microsoft_client_id.trim() : current.microsoft_client_id;
    const nextCurse = body.clear_curseforge === true ? "" : (typeof body.curseforge_api_key === "string" && body.curseforge_api_key.trim() ? body.curseforge_api_key.trim() : current.curseforge_api_key);
    const nextManifest = typeof body.update_manifest_url === "string" && body.update_manifest_url.trim() ? body.update_manifest_url.trim() : current.update_manifest_url;
    const nextVersion = typeof body.latest_launcher_version === "string" && body.latest_launcher_version.trim() ? body.latest_launcher_version.trim() : current.latest_launcher_version;
    await sql`update axolot_private.launcher_config set microsoft_client_id=${nextMicrosoft}, curseforge_api_key=${nextCurse}, update_manifest_url=${nextManifest}, latest_launcher_version=${nextVersion}, updated_at=now() where id=1`;
    return new Response(JSON.stringify({ ok: true, microsoft_client_id: nextMicrosoft, curseforge_api_key_masked: mask(nextCurse), curseforge_enabled: Boolean(nextCurse), update_manifest_url: nextManifest, latest_launcher_version: nextVersion }), { headers: cors });
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error?.message ?? error) }), { status: 500, headers: cors });
  } finally {
    await sql.end({ timeout: 1 }).catch(() => undefined);
  }
});
