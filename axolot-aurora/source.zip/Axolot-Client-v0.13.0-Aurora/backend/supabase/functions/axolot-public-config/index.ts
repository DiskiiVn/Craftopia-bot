import postgres from "postgres";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-axolot-admin",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type": "application/json",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "GET") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: cors });
  const dbUrl = Deno.env.get("SUPABASE_DB_URL");
  if (!dbUrl) return new Response(JSON.stringify({ error: "Database unavailable" }), { status: 500, headers: cors });
  const sql = postgres(dbUrl, { prepare: false, max: 1 });
  try {
    const rows = await sql`
      select microsoft_client_id, update_manifest_url, latest_launcher_version,
             (curseforge_api_key <> '') as curseforge_enabled, updated_at
      from axolot_private.launcher_config where id = 1 limit 1
    `;
    const row = rows[0] ?? {};
    const base = new URL(req.url).origin.replace(/\/functions\/v1$/, "");
    return new Response(JSON.stringify({
      microsoft_client_id: row.microsoft_client_id ?? "",
      update_manifest_url: row.update_manifest_url ?? "",
      latest_launcher_version: row.latest_launcher_version ?? "",
      curseforge_enabled: Boolean(row.curseforge_enabled),
      curseforge_proxy_url: base + "/functions/v1/axolot-curseforge",
      updated_at: row.updated_at ?? null,
    }), { headers: { ...cors, "Cache-Control": "public, max-age=60, stale-while-revalidate=300" } });
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error?.message ?? error) }), { status: 500, headers: cors });
  } finally {
    await sql.end({ timeout: 1 }).catch(() => undefined);
  }
});
