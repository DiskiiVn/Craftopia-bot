# Axolot Cloud Config Backend

Deployed project: `craftopia-production` / `rlbgvgosxrhqnppbrtey`.

Edge Functions:
- `axolot-public-config` — public read-only launcher configuration.
- `axolot-admin-config` — admin-only configuration mutation using `x-axolot-admin` token.
- `axolot-curseforge` — restricted CurseForge API proxy. API key remains server-side.

Do not put the CurseForge API key or any Microsoft client secret in the desktop launcher.
