create schema if not exists axolot_private;
revoke all on schema axolot_private from public, anon, authenticated;

create table if not exists axolot_private.launcher_config (
  id smallint primary key default 1 check (id = 1),
  microsoft_client_id text not null default '',
  curseforge_api_key text not null default '',
  update_manifest_url text not null default 'https://github.com/DiskiiVn/Craftopia-bot/releases/latest/download/axolot-update.json',
  latest_launcher_version text not null default '0.11.1',
  admin_token_sha256 text not null,
  updated_at timestamptz not null default now()
);

revoke all on all tables in schema axolot_private from public, anon, authenticated;
