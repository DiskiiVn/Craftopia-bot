# Axolot Client 0.12.4 RC

## Desktop shell
- Reworked Play screen into a fixed desktop dashboard.
- Whole launcher window no longer scrolls like a website.
- Left navigation is icon-first and fixed.
- Only content-heavy pages and lists scroll inside their own regions.
- Removed the large marketing headline and the “PLAY MINECRAFT” label.
- Launch is now a compact gradient icon control.

## Hands-free updater
- Automatic updates are enabled by default.
- Startup checks the configured release manifest before normal launcher initialization.
- If an update is available, Axolot downloads the Windows NSIS installer internally.
- The installer is SHA-256 verified before it is started.
- The updater launches the installer silently and closes the old launcher.
- While Minecraft is running, background update checks defer installation rather than interrupting the game.
- Axolot checks again on focus and every 10 minutes while open.

## Release channel
The included GitHub Actions workflow builds the Windows NSIS installer and creates `axolot-update.json` with the correct installer URL and SHA-256. The launcher currently defaults to:

`https://github.com/DiskiiVn/Craftopia-bot/releases/latest/download/axolot-update.json`

For a release, push the source to the repository that owns the update channel and run/tag the workflow as `axolot-v0.12.4`.
