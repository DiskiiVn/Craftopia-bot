import React from 'react';
import ReactDOM from 'react-dom/client';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import {
  Activity,
  AlertTriangle,
  Bell,
  Boxes,
  ChevronDown,
  ChevronRight,
  CircleEllipsis,
  Cpu,
  FileArchive,
  Download,
  FolderKanban,
  FolderOpen,
  Gamepad2,
  Handshake,
  HardDrive,
  MessageCircle,
  Package,
  Play,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  ShoppingCart,
  ShieldCheck,
  Terminal,
  Trash2,
  X,
  Sparkles,
  User,
  Users,
  UserPlus,
  LogIn,
  CheckCircle2,
  RefreshCw,
  Wifi,
  Zap,
} from 'lucide-react';
import './styles.css';

type Page = 'play' | 'profiles' | 'accounts' | 'partners' | 'store' | 'settings';
type Loader = 'Fabric' | 'Vanilla' | 'Forge' | 'NeoForge';
type AccountKind = 'offline' | 'microsoft';
type AccountFilter = 'all' | AccountKind;
type CatalogSource = 'modrinth' | 'curseforge';

type LauncherAccount = {
  id: string;
  username: string;
  kind: AccountKind;
  createdAt: number;
  uuid?: string;
  xuid?: string;
};

type VersionPreset = {
  id: string;
  title: string;
  subtitle: string;
  label: string;
};

type Profile = {
  id: string;
  name: string;
  versionId: string;
  loader: Loader;
  ram: number;
  modpack?: string;
  optimizationPreset?: string;
  autoOptimized?: boolean;
  isDefault?: boolean;
};

type LocalMod = {
  name: string;
  enabled: boolean;
  size_bytes: number;
};

type OptimizationPackResult = {
  installed: string[];
  failed: string[];
  preset: string;
  message: string;
};

type ModrinthProject = {
  project_id: string;
  title: string;
  description: string;
  icon_url?: string | null;
  author?: string;
  downloads?: number;
  versions?: string[];
  categories?: string[];
  project_type: 'mod' | 'modpack' | string;
  source?: CatalogSource;
};

type ModLibraryTab = 'installed' | 'browse-mods' | 'modpacks';

type LaunchProgressEvent = { stage: string; message: string; percent: number };
type LaunchResult = { pid: number; profile_dir: string; java_runtime: string; message: string };
type GameProcessStatus = {
  profile_id: string;
  state: 'running' | 'stopped' | 'crashed' | string;
  pid?: number | null;
  exit_code?: number | null;
  message: string;
};
type GameConsoleLine = { profile_id: string; stream: string; timestamp_ms: number; line: string };
type CrashLineData = { number: number; level: 'error' | 'warn' | 'stack' | 'info' | string; text: string };
type CrashReportData = {
  profile_id: string;
  exit_code?: number | null;
  summary: string;
  source: string;
  lines: CrashLineData[];
  suspicious: CrashLineData[];
};

type MicrosoftDeviceCode = { device_code: string; user_code: string; verification_uri: string; message: string; expires_in: number; interval: number };
type MicrosoftLoginResult = { account_id: string; username: string; uuid: string; xuid: string; expires_at_ms: number };
type LauncherUpdateStatus = { current_version: string; latest_version: string; available: boolean; download_url: string; sha256: string; notes: string; mandatory: boolean };
type RemoteConfig = { microsoft_client_id: string; update_manifest_url: string; latest_launcher_version: string; curseforge_enabled: boolean; curseforge_proxy_url: string; updated_at?: string | null };
type HealthState = 'ok' | 'warn' | 'error' | 'checking';
type HealthItem = { id: string; label: string; state: HealthState; detail: string };

const AXOLOT_PUBLIC_CONFIG_URL = 'https://rlbgvgosxrhqnppbrtey.supabase.co/functions/v1/axolot-public-config';
const DEFAULT_UPDATE_MANIFEST = 'https://rlbgvgosxrhqnppbrtey.supabase.co/storage/v1/object/public/axolot-releases/stable/axolot-update.json';
const MINECRAFT_APP_APPROVAL_URL = 'https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=v4j5cvGGr0GRqy180BHbR-ajEQ1td1ROpz00KtS8Gd5UNVpPTkVLNFVROVQxNkdRMEtXVjNQQjdXVC4u';
const MINECRAFT_APP_INFO_URL = 'https://help.minecraft.net/hc/en-us/articles/16254801392141';

const isMinecraftAppRegistrationError = (message: string) => /invalid app registration|allowlist|approved\/allowlisted/i.test(message);

const nav: { id: Page; icon: React.ElementType; label: string }[] = [
  { id: 'play', icon: Play, label: 'Play' },
  { id: 'profiles', icon: Boxes, label: 'Profiles' },
  { id: 'accounts', icon: Users, label: 'Accounts' },
  { id: 'partners', icon: Handshake, label: 'Partners' },
  { id: 'store', icon: ShoppingCart, label: 'Store' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

const versionCatalog: VersionPreset[] = [
  { id: '1.21.11', title: 'Minecraft 1.21.11', subtitle: 'Latest stable build • Great for your server', label: 'Recommended' },
  { id: '1.21.4', title: 'Minecraft 1.21.4', subtitle: 'Popular version • Smooth performance', label: 'Stable' },
  { id: '1.21.1', title: 'Minecraft 1.21.1', subtitle: 'Compatible with many Fabric mods', label: 'Mods Ready' },
  { id: '1.20.1', title: 'Minecraft 1.20.1', subtitle: 'Massive mod support • Classic favorite', label: 'Modded' },
  { id: '1.8.9', title: 'Minecraft 1.8.9', subtitle: 'PvP / legacy profile support', label: 'Legacy' },
];

const starterProfiles: Profile[] = [
  {
    id: 'survival-main',
    name: 'Ryn Survival',
    versionId: '1.21.11',
    loader: 'Fabric',
    ram: 4,
    modpack: 'Axolot FPS Pack',
    isDefault: true,
  },
  {
    id: 'builder-pack',
    name: 'Smooth Vanilla',
    versionId: '1.21.4',
    loader: 'Vanilla',
    ram: 4,
    modpack: 'Clean profile',
  },
];

const fallbackMods: ModrinthProject[] = [
  { project_id: 'sodium', title: 'Sodium', description: 'A modern rendering engine that dramatically improves Minecraft performance.', author: 'CaffeineMC', downloads: 120000000, versions: ['1.21.11', '1.21.4', '1.21.1'], categories: ['fabric', 'optimization'], project_type: 'mod' },
  { project_id: 'lithium', title: 'Lithium', description: 'General-purpose optimization for game physics, mob AI and server logic.', author: 'CaffeineMC', downloads: 90000000, versions: ['1.21.11', '1.21.4', '1.21.1'], categories: ['fabric', 'optimization'], project_type: 'mod' },
  { project_id: 'iris', title: 'Iris Shaders', description: 'Shader loader designed to work beautifully with Sodium.', author: 'IrisShaders', downloads: 80000000, versions: ['1.21.4', '1.21.1'], categories: ['fabric', 'shaders'], project_type: 'mod' },
  { project_id: 'modmenu', title: 'Mod Menu', description: 'A clean list and configuration entry point for installed Fabric mods.', author: 'TerraformersMC', downloads: 70000000, versions: ['1.21.11', '1.21.4', '1.21.1'], categories: ['fabric', 'utility'], project_type: 'mod' },
];

const fallbackModpacks: ModrinthProject[] = [
  { project_id: 'axolot-performance', title: 'Axolot Performance', description: 'Lightweight FPS-focused Fabric pack with sensible defaults.', author: 'Axolot Client', downloads: 0, versions: ['1.21.11'], categories: ['fabric', 'optimization'], project_type: 'modpack' },
  { project_id: 'fabulously-optimized', title: 'Fabulously Optimized', description: 'Performance and graphics focused Fabric modpack with broad compatibility.', author: 'Fabulously Optimized', downloads: 12000000, versions: ['1.21.4', '1.21.1'], categories: ['fabric', 'optimization'], project_type: 'modpack' },
  { project_id: 'simply-optimized', title: 'Simply Optimized', description: 'Minimal performance pack focused on speed and responsiveness.', author: 'SO Team', downloads: 5000000, versions: ['1.21.4', '1.21.1'], categories: ['fabric', 'optimization'], project_type: 'modpack' },
];

function getVersionMeta(versionId: string) {
  return versionCatalog.find((item) => item.id === versionId) ?? versionCatalog[0];
}

function loadProfiles() {
  try {
    const raw = localStorage.getItem('axolot.profiles');
    if (!raw) return starterProfiles;
    const parsed = JSON.parse(raw) as Profile[];
    return parsed.length ? parsed : starterProfiles;
  } catch {
    return starterProfiles;
  }
}

function sanitizeMinecraftName(value: string) {
  return value.replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
}

function loadAccounts(defaultName: string): LauncherAccount[] {
  try {
    const raw = localStorage.getItem('axolot.accounts');
    if (raw) {
      const parsed = JSON.parse(raw) as LauncherAccount[];
      const valid = parsed.filter((account) => account && account.id && account.username);
      if (valid.length) return valid;
    }
  } catch {
    // Fall back to the legacy single offline account below.
  }
  return [{
    id: 'offline-primary',
    username: sanitizeMinecraftName(defaultName) || 'Player',
    kind: 'offline',
    createdAt: Date.now(),
  }];
}

function App() {
  const legacyOfflineName = localStorage.getItem('axolot.offlineName') || 'DiskiiVN';
  const [page, setPage] = React.useState<Page>('play');
  const [accounts, setAccounts] = React.useState<LauncherAccount[]>(() => loadAccounts(legacyOfflineName));
  const [activeAccountId, setActiveAccountId] = React.useState<string>(() => localStorage.getItem('axolot.activeAccountId') || 'offline-primary');
  const [launcherName, setLauncherName] = React.useState(legacyOfflineName);
  const [newAccountName, setNewAccountName] = React.useState('');
  const [accountSearch, setAccountSearch] = React.useState('');
  const [accountFilter, setAccountFilter] = React.useState<AccountFilter>('all');
  const [bulkAccountNames, setBulkAccountNames] = React.useState('');
  const [microsoftSessionStates, setMicrosoftSessionStates] = React.useState<Record<string, boolean | null>>({});
  const [status, setStatus] = React.useState('Client is ready');
  const [progress, setProgress] = React.useState(100);
  const [globalRam, setGlobalRam] = React.useState(Number(localStorage.getItem('axolot.ram') || 6));
  const [profiles, setProfiles] = React.useState<Profile[]>(loadProfiles);
  const [profileSearch, setProfileSearch] = React.useState('');
  const [creatingProfile, setCreatingProfile] = React.useState(false);
  const [selectedVersionId, setSelectedVersionId] = React.useState('1.21.11');
  const [selectedLoader, setSelectedLoader] = React.useState<Loader>('Fabric');
  const [newProfileName, setNewProfileName] = React.useState('My Fabric Profile');
  const [newProfileRam, setNewProfileRam] = React.useState(4);
  const [newProfileModpack, setNewProfileModpack] = React.useState('');
  const [activeProfileId, setActiveProfileId] = React.useState<string>(() => {
    const stored = localStorage.getItem('axolot.activeProfileId');
    return stored || starterProfiles[0].id;
  });
  const [managingModsProfileId, setManagingModsProfileId] = React.useState<string | null>(null);
  const [modLibraryTab, setModLibraryTab] = React.useState<ModLibraryTab>('installed');
  const [localMods, setLocalMods] = React.useState<LocalMod[]>([]);
  const [modFileSearch, setModFileSearch] = React.useState('');
  const [catalogQuery, setCatalogQuery] = React.useState('');
  const [catalogProjects, setCatalogProjects] = React.useState<ModrinthProject[]>([]);
  const [catalogLoading, setCatalogLoading] = React.useState(false);
  const [catalogMessage, setCatalogMessage] = React.useState('Search Modrinth or CurseForge using compatibility filters.');
  const [catalogSource, setCatalogSource] = React.useState<CatalogSource>(() => (localStorage.getItem('axolot.catalogSource') as CatalogSource) || 'modrinth');
  const [remoteConfig, setRemoteConfig] = React.useState<RemoteConfig | null>(null);
  const [curseForgeEnabled, setCurseForgeEnabled] = React.useState(false);
  const [launching, setLaunching] = React.useState(false);
  const [launchStage, setLaunchStage] = React.useState('ready');
  const [serverAddress, setServerAddress] = React.useState(localStorage.getItem('axolot.serverAddress') || '');
  const [consoleOpen, setConsoleOpen] = React.useState(false);
  const [consoleText, setConsoleText] = React.useState('No game console output yet.');
  const [booting, setBooting] = React.useState(true);
  const [bootMessage, setBootMessage] = React.useState('Starting Axolot Client...');
  const [bootPercent, setBootPercent] = React.useState(8);
  const [microsoftClientId, setMicrosoftClientId] = React.useState('');
  const [microsoftBusy, setMicrosoftBusy] = React.useState(false);
  const [microsoftDevice, setMicrosoftDevice] = React.useState<MicrosoftDeviceCode | null>(null);
  const [microsoftError, setMicrosoftError] = React.useState('');
  const [microsoftStage, setMicrosoftStage] = React.useState('');
  const [updateManifestUrl, setUpdateManifestUrl] = React.useState(DEFAULT_UPDATE_MANIFEST);
  const [autoInstallUpdates, setAutoInstallUpdates] = React.useState(localStorage.getItem('axolot.autoInstallUpdates') !== 'false');
  const [updateStatus, setUpdateStatus] = React.useState<LauncherUpdateStatus | null>(null);
  const [updatePromptOpen, setUpdatePromptOpen] = React.useState(false);
  const [updatingLauncher, setUpdatingLauncher] = React.useState(false);
  const [gameStatus, setGameStatus] = React.useState<GameProcessStatus | null>(null);
  const [crashOpen, setCrashOpen] = React.useState(false);
  const [crashReport, setCrashReport] = React.useState<CrashReportData | null>(null);
  const [healthBusy, setHealthBusy] = React.useState(false);
  const [healthItems, setHealthItems] = React.useState<HealthItem[]>([
    { id: 'cloud', label: 'Axolot Cloud', state: 'checking', detail: 'Not checked yet' },
    { id: 'engine', label: 'Game engine', state: 'checking', detail: 'Not checked yet' },
    { id: 'updates', label: 'Update channel', state: 'checking', detail: 'Not checked yet' },
    { id: 'modrinth', label: 'Modrinth', state: 'checking', detail: 'Not checked yet' },
    { id: 'curseforge', label: 'CurseForge', state: 'checking', detail: 'Not checked yet' },
  ]);
  const consoleEndRef = React.useRef<HTMLDivElement | null>(null);

  const activeAccount = accounts.find((account) => account.id === activeAccountId) ?? accounts[0];
  const offlineAccountCount = accounts.filter((account) => account.kind === 'offline').length;
  const microsoftAccountCount = accounts.filter((account) => account.kind === 'microsoft').length;
  const visibleAccounts = accounts.filter((account) => (accountFilter === 'all' || account.kind === accountFilter) && account.username.toLowerCase().includes(accountSearch.toLowerCase()));
  const microsoftNeedsApproval = isMinecraftAppRegistrationError(microsoftError);

  React.useEffect(() => {
    localStorage.setItem('axolot.accounts', JSON.stringify(accounts));
  }, [accounts]);

  React.useEffect(() => {
    if (!activeAccount) return;
    localStorage.setItem('axolot.activeAccountId', activeAccount.id);
    if (activeAccount.kind === 'offline') {
      setLauncherName(activeAccount.username);
      localStorage.setItem('axolot.offlineName', activeAccount.username);
    }
  }, [activeAccount?.id, activeAccount?.username, activeAccount?.kind]);

  React.useEffect(() => {
    const clientId = microsoftClientId.trim();
    if (!clientId) return;
    let cancelled = false;
    const restoreSavedAccounts = async () => {
      const microsoftAccounts = accounts.filter((account) => account.kind === 'microsoft');
      for (const account of microsoftAccounts) {
        if (cancelled) return;
        setMicrosoftSessionStates((current) => ({ ...current, [account.id]: null }));
        try {
          const result = await invoke<MicrosoftLoginResult>('restore_microsoft_session', { accountId: account.id, clientId });
          if (cancelled) return;
          setAccounts((current) => current.map((item) => item.id === account.id ? { ...item, username: result.username, uuid: result.uuid, xuid: result.xuid } : item));
          setMicrosoftSessionStates((current) => ({ ...current, [account.id]: true }));
        } catch {
          if (!cancelled) setMicrosoftSessionStates((current) => ({ ...current, [account.id]: false }));
        }
      }
    };
    void restoreSavedAccounts();
    return () => { cancelled = true; };
  }, [microsoftClientId]);

  React.useEffect(() => {
    localStorage.setItem('axolot.profiles', JSON.stringify(profiles));
  }, [profiles]);

  React.useEffect(() => {
    let stop: (() => void) | undefined;
    listen<LaunchProgressEvent>('launch-progress', (event) => {
      setLaunchStage(event.payload.stage);
      setStatus(event.payload.message);
      setProgress(event.payload.percent);
    }).then((unlisten) => { stop = unlisten; });
    return () => stop?.();
  }, []);

  React.useEffect(() => {
    localStorage.setItem('axolot.activeProfileId', activeProfileId);
  }, [activeProfileId]);

  const activeProfile = profiles.find((profile) => profile.id === activeProfileId) ?? profiles[0];

  React.useEffect(() => {
    let disposed = false;
    let unlistenStatus: (() => void) | undefined;
    let unlistenConsole: (() => void) | undefined;
    let unlistenCrash: (() => void) | undefined;

    listen<GameProcessStatus>('game-status', (event) => {
      if (!activeProfile || event.payload.profile_id !== activeProfile.id) return;
      setGameStatus(event.payload);
      if (event.payload.state === 'crashed') {
        setStatus(`CRASHED • ${event.payload.message}`);
      }
    }).then((fn) => { if (disposed) fn(); else unlistenStatus = fn; });

    listen<GameConsoleLine>('game-console-line', (event) => {
      if (!activeProfile || event.payload.profile_id !== activeProfile.id) return;
      const stamp = new Date(Number(event.payload.timestamp_ms)).toLocaleTimeString([], { hour12: false });
      const prefix = event.payload.stream === 'stderr' ? 'ERR' : 'OUT';
      setConsoleText((current) => {
        const next = `${current && !current.startsWith('No game') ? `${current}\n` : ''}[${stamp}][${prefix}] ${event.payload.line}`;
        return next.split('\n').slice(-1400).join('\n');
      });
    }).then((fn) => { if (disposed) fn(); else unlistenConsole = fn; });

    listen<CrashReportData>('game-crash', (event) => {
      if (!activeProfile || event.payload.profile_id !== activeProfile.id) return;
      setCrashReport(event.payload);
      setCrashOpen(true);
      setGameStatus({
        profile_id: event.payload.profile_id,
        state: 'crashed',
        pid: null,
        exit_code: event.payload.exit_code,
        message: event.payload.summary,
      });
      setStatus(`Minecraft crashed • ${event.payload.summary}`);
    }).then((fn) => { if (disposed) fn(); else unlistenCrash = fn; });

    return () => {
      disposed = true;
      unlistenStatus?.();
      unlistenConsole?.();
      unlistenCrash?.();
    };
  }, [activeProfile?.id]);

  React.useEffect(() => {
    if (!activeProfile) return;
    let mounted = true;
    const refresh = async (first = false) => {
      try {
        const next = await invoke<GameProcessStatus>('get_game_status', { profileId: activeProfile.id });
        if (mounted) setGameStatus(next);
      } catch {
        if (mounted) setGameStatus({ profile_id: activeProfile.id, state: 'stopped', pid: null, exit_code: null, message: 'Game monitor unavailable in preview mode.' });
      } finally {
        void first;
      }
    };
    void refresh(true);
    const timer = window.setInterval(() => void refresh(false), 2500);
    return () => { mounted = false; window.clearInterval(timer); };
  }, [activeProfile?.id]);

  React.useEffect(() => {
    let cancelled = false;
    const wait = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms));
    const boot = async () => {
      setBooting(true);
      setBootPercent(10);
      setBootMessage('Loading identity vault...');
      await wait(220);
      if (cancelled) return;
      setBootPercent(32);
      setBootMessage('Checking profiles and game state...');
      await wait(260);
      if (cancelled) return;
      setBootPercent(52);
      setBootMessage('Syncing Axolot cloud configuration...');
      let manifestForBoot = DEFAULT_UPDATE_MANIFEST;
      try {
        const response = await fetch(AXOLOT_PUBLIC_CONFIG_URL, { cache: 'no-store' });
        if (response.ok) {
          const config = await response.json() as RemoteConfig;
          if (cancelled) return;
          setRemoteConfig(config);
          setMicrosoftClientId((config.microsoft_client_id || '').trim());
          setCurseForgeEnabled(Boolean(config.curseforge_enabled));
          manifestForBoot = (config.update_manifest_url || DEFAULT_UPDATE_MANIFEST).trim();
          setUpdateManifestUrl(manifestForBoot);
        }
      } catch {
        // Cloud configuration is optional for offline-only use.
      }
      if (cancelled) return;
      setBootPercent(64);
      setBootMessage('Checking Axolot update channel...');
      try {
        const update = await invoke<LauncherUpdateStatus>('check_launcher_update', { manifestUrl: manifestForBoot });
        if (cancelled) return;
        setUpdateStatus(update);
        if (update.available) {
          if (autoInstallUpdates) {
            setBootPercent(76);
            setBootMessage(`Updating Axolot to ${update.latest_version}...`);
            setUpdatingLauncher(true);
            try {
              await invoke<string>('install_launcher_update', { downloadUrl: update.download_url, sha256: update.sha256 });
              return;
            } catch (error) {
              setUpdatingLauncher(false);
              setStatus(String(error).replace(/^Error: /, ''));
              setUpdatePromptOpen(true);
            }
          } else {
            setBootMessage(`Axolot ${update.latest_version} is ready.`);
            const dismissed = sessionStorage.getItem('axolot.dismissedUpdateVersion');
            if (dismissed !== update.latest_version) setUpdatePromptOpen(true);
          }
        }
      } catch {
        // The launcher remains usable when the update endpoint is temporarily unavailable.
      }
      if (cancelled) return;
      setBootPercent(84);
      setBootMessage('Initializing Minecraft services...');
      await wait(260);
      if (cancelled) return;
      setBootPercent(100);
      setBootMessage('Axolot Client is ready.');
      await wait(260);
      if (!cancelled) setBooting(false);
    };
    void boot();
    return () => { cancelled = true; };
  }, []);

  React.useEffect(() => {
    if (booting || !autoInstallUpdates) return;
    let cancelled = false;
    const silentCheck = async () => {
      try {
        const next = await invoke<LauncherUpdateStatus>('check_launcher_update', { manifestUrl: updateManifestUrl.trim() || DEFAULT_UPDATE_MANIFEST });
        if (cancelled) return;
        setUpdateStatus(next);
        if (next.available) {
          if (autoInstallUpdates && gameStatus?.state !== 'running' && !updatingLauncher) {
            setUpdatingLauncher(true);
            setStatus(`Updating Axolot ${next.latest_version}...`);
            try {
              await invoke<string>('install_launcher_update', { downloadUrl: next.download_url, sha256: next.sha256 });
              return;
            } catch (error) {
              setUpdatingLauncher(false);
              setStatus(String(error).replace(/^Error: /, ''));
              setUpdatePromptOpen(true);
            }
          } else {
            const dismissed = sessionStorage.getItem('axolot.dismissedUpdateVersion');
            if (dismissed !== next.latest_version) setUpdatePromptOpen(true);
          }
        }
      } catch {
        // Background update checks should never interrupt gameplay or navigation.
      }
    };
    const timer = window.setInterval(() => void silentCheck(), 10 * 60 * 1000);
    const onFocus = () => void silentCheck();
    window.addEventListener('focus', onFocus);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
      window.removeEventListener('focus', onFocus);
    };
  }, [booting, autoInstallUpdates, updateManifestUrl, gameStatus?.state, updatingLauncher]);

  React.useEffect(() => {
    if (!consoleOpen) return;
    const timer = window.setTimeout(() => consoleEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }), 60);
    return () => window.clearTimeout(timer);
  }, [consoleText, consoleOpen]);

  React.useEffect(() => {
    if (activeProfile) {
      setSelectedVersionId(activeProfile.versionId);
      setSelectedLoader(activeProfile.loader);
      setNewProfileRam(activeProfile.ram);
    }
  }, [activeProfile?.id]);

  const saveSettings = () => {
    const cleaned = sanitizeMinecraftName(launcherName) || activeAccount?.username || 'Player';
    if (activeAccount?.kind === 'offline' && cleaned !== activeAccount.username) {
      setAccounts((current) => current.map((account) =>
        account.id === activeAccount.id ? { ...account, username: cleaned } : account
      ));
    }
    localStorage.setItem('axolot.offlineName', cleaned);
    localStorage.setItem('axolot.ram', String(globalRam));
    localStorage.setItem('axolot.serverAddress', serverAddress.trim());
    localStorage.setItem('axolot.catalogSource', catalogSource);
    localStorage.setItem('axolot.autoInstallUpdates', String(autoInstallUpdates));
    setStatus('Settings saved');
  };

  const selectAccount = (account: LauncherAccount) => {
    setActiveAccountId(account.id);
    if (account.kind === 'offline') setLauncherName(account.username);
    setStatus(`Active account: ${account.username}`);
  };

  const addOfflineAccount = () => {
    const username = sanitizeMinecraftName(newAccountName);
    if (!username) {
      setStatus('Enter a valid Minecraft username.');
      return;
    }
    if (accounts.some((account) => account.kind === 'offline' && account.username.toLowerCase() === username.toLowerCase())) {
      setStatus('That offline account already exists.');
      return;
    }
    const account: LauncherAccount = {
      id: `offline-${Date.now()}`,
      username,
      kind: 'offline',
      createdAt: Date.now(),
    };
    setAccounts((current) => [...current, account]);
    setActiveAccountId(account.id);
    setLauncherName(account.username);
    setNewAccountName('');
    setStatus(`Added ${username} and made it active.`);
  };

  const addOfflineAccountsBulk = () => {
    const requested = bulkAccountNames.split(/[\s,;]+/).map(sanitizeMinecraftName).filter(Boolean);
    const existing = new Set(accounts.filter((account) => account.kind === 'offline').map((account) => account.username.toLowerCase()));
    const unique = requested.filter((name, index) => requested.findIndex((candidate) => candidate.toLowerCase() === name.toLowerCase()) === index && !existing.has(name.toLowerCase()));
    if (!unique.length) {
      setStatus('No new valid offline usernames found.');
      return;
    }
    const created = unique.map((username, index): LauncherAccount => ({
      id: `offline-${Date.now()}-${index}`,
      username,
      kind: 'offline',
      createdAt: Date.now() + index,
    }));
    setAccounts((current) => [...current, ...created]);
    setActiveAccountId(created[0].id);
    setLauncherName(created[0].username);
    setBulkAccountNames('');
    setStatus(`Added ${created.length} offline account${created.length === 1 ? '' : 's'}.`);
  };

  const ensureMicrosoftSession = async (account: LauncherAccount) => {
    const clientId = microsoftClientId.trim();
    if (!clientId) throw new Error('Microsoft sign-in is not configured by the Axolot administrator yet.');
    const alive = await invoke<boolean>('microsoft_session_active', { accountId: account.id });
    if (alive) {
      setMicrosoftSessionStates((current) => ({ ...current, [account.id]: true }));
      return;
    }
    setMicrosoftSessionStates((current) => ({ ...current, [account.id]: null }));
    const result = await invoke<MicrosoftLoginResult>('restore_microsoft_session', { accountId: account.id, clientId });
    setAccounts((current) => current.map((item) => item.id === account.id ? { ...item, username: result.username, uuid: result.uuid, xuid: result.xuid } : item));
    setMicrosoftSessionStates((current) => ({ ...current, [account.id]: true }));
  };

  const deleteAccount = (accountId: string) => {
    const deleting = accounts.find((account) => account.id === accountId);
    if (deleting?.kind === 'microsoft') void invoke('microsoft_logout', { accountId }).catch(() => undefined);
    if (accounts.length <= 1) {
      setStatus('Keep at least one account in Axolot Client.');
      return;
    }
    const removingActive = accountId === activeAccountId;
    const remaining = accounts.filter((account) => account.id !== accountId);
    setAccounts(remaining);
    setMicrosoftSessionStates((current) => {
      const next = { ...current };
      delete next[accountId];
      return next;
    });
    if (removingActive && remaining[0]) {
      setActiveAccountId(remaining[0].id);
      if (remaining[0].kind === 'offline') setLauncherName(remaining[0].username);
    }
    setStatus('Account removed from this launcher.');
  };

  const openMinecraftApproval = async () => {
    try {
      await navigator.clipboard?.writeText(microsoftClientId.trim());
    } catch {
      // Clipboard permissions are optional; the approval page still opens.
    }
    setStatus('Axolot Client ID copied. Submit it to Minecraft AppID approval, then retry after approval.');
    void invoke('open_external_url', { url: MINECRAFT_APP_APPROVAL_URL }).catch(() => {
      void invoke('open_external_url', { url: MINECRAFT_APP_INFO_URL }).catch(() => undefined);
    });
  };

  const continueOfflineAfterMicrosoftBlock = () => {
    const offline = accounts.find((account) => account.kind === 'offline');
    if (offline) {
      setActiveAccountId(offline.id);
      setLauncherName(offline.username);
    }
    setMicrosoftDevice(null);
    setMicrosoftError('');
    setMicrosoftStage('');
    setPage('play');
    setStatus('Minecraft Premium login is waiting for AppID approval. Offline mode remains available for compatible servers.');
  };

  const connectMicrosoftAccount = async () => {
    const clientId = microsoftClientId.trim();
    if (!clientId) {
      setPage('settings');
      setStatus('Microsoft sign-in is not configured by the Axolot administrator yet.');
      return;
    }
    if (microsoftBusy) return;
    setMicrosoftBusy(true);
    setMicrosoftError('');
    setMicrosoftStage('Requesting a secure Microsoft device code…');
    setStatus('Starting Microsoft secure sign-in...');
    try {
      const device = await invoke<MicrosoftDeviceCode>('begin_microsoft_login', { clientId });
      setMicrosoftDevice(device);
      setMicrosoftStage('Waiting for Microsoft authorization…');
      setStatus(`Microsoft sign-in code: ${device.user_code}`);
      void invoke('open_external_url', { url: device.verification_uri }).catch(() => undefined);
      const result = await invoke<MicrosoftLoginResult>('complete_microsoft_login', {
        clientId,
        deviceCode: device.device_code,
        expiresIn: device.expires_in,
        interval: device.interval,
      });
      setMicrosoftStage('Minecraft profile verified. Finishing sign-in…');
      const next: LauncherAccount = {
        id: result.account_id, username: result.username, kind: 'microsoft', createdAt: Date.now(), uuid: result.uuid, xuid: result.xuid,
      };
      setAccounts((current) => {
        const existing = current.findIndex((item) => item.id === next.id);
        if (existing < 0) return [...current, next];
        return current.map((item) => item.id === next.id ? { ...item, ...next } : item);
      });
      setActiveAccountId(next.id);
      setMicrosoftSessionStates((current) => ({ ...current, [next.id]: true }));
      setMicrosoftDevice(null);
      setMicrosoftError('');
      setMicrosoftStage('');
      setStatus(`Signed in with Microsoft as ${result.username}.`);
    } catch (error) {
      const message = String(error).replace(/^Error: /, '');
      setMicrosoftError(message);
      setMicrosoftStage('Sign-in stopped. See the exact error below.');
      setStatus(message);
    } finally {
      setMicrosoftBusy(false);
    }
  };

  const checkForUpdates = async () => {
    setStatus('Checking for Axolot Client updates...');
    try {
      const next = await invoke<LauncherUpdateStatus>('check_launcher_update', { manifestUrl: updateManifestUrl.trim() || DEFAULT_UPDATE_MANIFEST });
      setUpdateStatus(next);
      if (next.available) {
        sessionStorage.removeItem('axolot.dismissedUpdateVersion');
        setUpdatePromptOpen(true);
      }
      setStatus(next.available ? `Axolot ${next.latest_version} is available.` : `Axolot ${next.current_version} is up to date.`);
    } catch (error) {
      setStatus(String(error).replace(/^Error: /, ''));
    }
  };

  const installUpdateNow = async () => {
    if (!updateStatus?.available || updatingLauncher) return;
    setUpdatingLauncher(true);
    setUpdatePromptOpen(true);
    setStatus(`Downloading Axolot ${updateStatus.latest_version}...`);
    try {
      await invoke<string>('install_launcher_update', { downloadUrl: updateStatus.download_url, sha256: updateStatus.sha256 });
    } catch (error) {
      setUpdatingLauncher(false);
      setStatus(String(error).replace(/^Error: /, ''));
    }
  };

  const renameActiveOfflineAccount = (value: string) => {
    const cleaned = sanitizeMinecraftName(value);
    setLauncherName(cleaned);
    if (activeAccount?.kind !== 'offline') return;
    setAccounts((current) => current.map((account) =>
      account.id === activeAccount.id ? { ...account, username: cleaned } : account
    ));
  };

  const sync = async () => {
    setStatus('Checking Axolot Client files...');
    setProgress(35);
    try {
      const result = await invoke<string>('sync_manifest', {
        manifestUrl: 'https://example.com/axolot/manifest.json',
      });
      setStatus(result);
    } catch {
      setStatus('Demo manifest is not connected to a CDN yet');
    }
    setProgress(100);
  };

  const launchProfile = async (profile: Profile) => {
    if (launching || gameStatus?.state === 'running') return;
    saveSettings();
    setActiveProfileId(profile.id);
    setLaunching(true);
    setLaunchStage('start');
    setStatus(`Preparing ${profile.name}...`);
    setProgress(2);
    try {
      if (activeAccount?.kind === 'microsoft') {
        setLaunchStage('account');
        setStatus(`Restoring Microsoft session for ${activeAccount.username}...`);
        setProgress(6);
        await ensureMicrosoftSession(activeAccount);
      }
      if (profile.loader === 'Fabric' && !profile.autoOptimized) {
        setLaunchStage('autoboost');
        setStatus('Installing Axolot AutoBoost • Sodium • Mod Menu • performance mods...');
        setProgress(10);
        const boost = await invoke<OptimizationPackResult>('install_optimization_pack', {
          profileId: profile.id,
          gameVersion: profile.versionId,
          loader: profile.loader,
          ramGb: profile.ram,
        });
        setProfiles((current) => current.map((item) => item.id === profile.id
          ? { ...item, autoOptimized: true, optimizationPreset: boost.preset }
          : item));
      }

      const result = await invoke<LaunchResult>('launch_profile', {
        profileId: profile.id,
        profileName: profile.name,
        username: activeAccount?.username || launcherName,
        accountId: activeAccount?.id || null,
        accountKind: activeAccount?.kind || 'offline',
        gameVersion: profile.versionId,
        loader: profile.loader,
        ramGb: profile.ram,
        serverAddress: serverAddress.trim() || null,
      });
      setStatus(result.message);
      setProgress(100);
      setLaunchStage('done');
      setGameStatus({ profile_id: profile.id, state: 'running', pid: result.pid, exit_code: null, message: result.message });
    } catch (error) {
      setStatus(`Launch failed: ${String(error)}`);
      setProgress(100);
      setLaunchStage('error');
    } finally {
      setLaunching(false);
    }
  };

  const showGameConsole = async () => {
    if (!activeProfile) return;
    setConsoleOpen(true);
    setConsoleText('Loading live console history...');
    try {
      setConsoleText(await invoke<string>('read_game_console', { profileId: activeProfile.id }));
    } catch (error) {
      setConsoleText(`Could not read console: ${String(error)}`);
    }
  };

  const showCrashCenter = async () => {
    if (!activeProfile) return;
    setCrashOpen(true);
    try {
      setCrashReport(await invoke<CrashReportData>('read_crash_report', { profileId: activeProfile.id }));
    } catch (error) {
      setCrashReport({
        profile_id: activeProfile.id,
        exit_code: gameStatus?.exit_code ?? null,
        summary: `Could not load crash report: ${String(error)}`,
        source: 'launcher',
        lines: [],
        suspicious: [],
      });
    }
  };

  const openProfileFolder = async (profile: Profile) => {
    try {
      await invoke('open_profile_folder', { profileId: profile.id });
    } catch (error) {
      setStatus(`Could not open profile folder: ${String(error)}`);
    }
  };

  const createProfile = async () => {
    const version = getVersionMeta(selectedVersionId);
    const cleanedName = newProfileName.trim() || `${version.title} ${selectedLoader}`;
    const nextProfile: Profile = {
      id: `profile-${Date.now()}`,
      name: cleanedName,
      versionId: selectedVersionId,
      loader: selectedLoader,
      ram: newProfileRam,
      modpack: newProfileModpack.trim() || undefined,
      autoOptimized: false,
      isDefault: profiles.length === 0,
    };

    const nextProfiles = [...profiles, nextProfile];
    setProfiles(nextProfiles);
    setActiveProfileId(nextProfile.id);
    setCreatingProfile(false);
    setPage('profiles');

    if (selectedLoader !== 'Fabric') {
      setStatus(`Created ${nextProfile.name}. Axolot AutoBoost with Sodium is enabled automatically on Fabric profiles.`);
      setProgress(100);
      return;
    }

    setStatus(`Creating ${nextProfile.name} • installing Axolot AutoBoost...`);
    setProgress(18);
    try {
      const result = await invoke<OptimizationPackResult>('install_optimization_pack', {
        profileId: nextProfile.id,
        gameVersion: nextProfile.versionId,
        loader: nextProfile.loader,
        ramGb: nextProfile.ram,
      });

      setProfiles((current) => current.map((profile) =>
        profile.id === nextProfile.id
          ? { ...profile, optimizationPreset: result.preset, autoOptimized: true }
          : profile
      ));
      setStatus(result.message);
      setProgress(100);
      setManagingModsProfileId(nextProfile.id);
      setLocalMods([]);
      await refreshLocalMods(nextProfile.id);
    } catch (error) {
      setStatus(`Profile created, but AutoBoost could not finish: ${String(error)}`);
      setProgress(100);
    }
  };

  const makeDefault = (profileId: string) => {
    setProfiles((current) =>
      current.map((profile) => ({
        ...profile,
        isDefault: profile.id === profileId,
      })),
    );
    setStatus('Default profile updated');
  };

  const managedProfile = profiles.find((profile) => profile.id === managingModsProfileId) ?? activeProfile;

  const refreshLocalMods = async (profileId: string) => {
    try {
      const result = await invoke<LocalMod[]>('list_profile_mods', { profileId });
      setLocalMods(result);
      setCatalogMessage(`${result.length} local mod file(s) detected for this profile.`);
    } catch {
      setLocalMods([]);
      setCatalogMessage('Backend not running yet — UI preview mode is active.');
    }
  };

  const ensureProfileOptimization = async (profile: Profile) => {
    if (profile.loader !== 'Fabric' || profile.autoOptimized) {
      await refreshLocalMods(profile.id);
      return;
    }
    setCatalogMessage('Preparing this Fabric profile • installing Axolot AutoBoost mods…');
    try {
      const result = await invoke<OptimizationPackResult>('install_optimization_pack', {
        profileId: profile.id,
        gameVersion: profile.versionId,
        loader: profile.loader,
        ramGb: profile.ram,
      });
      setProfiles((current) => current.map((item) => item.id === profile.id
        ? { ...item, autoOptimized: true, optimizationPreset: result.preset }
        : item));
      setCatalogMessage(result.message);
    } catch (error) {
      setCatalogMessage(`AutoBoost could not finish: ${String(error)}`);
    } finally {
      await refreshLocalMods(profile.id);
    }
  };

  const openModLibrary = (profile: Profile, tab: ModLibraryTab = 'installed') => {
    setActiveProfileId(profile.id);
    setManagingModsProfileId(profile.id);
    setCreatingProfile(false);
    setPage('profiles');
    setModLibraryTab(tab);
    setCatalogQuery('');
    setCatalogProjects([]);
    void ensureProfileOptimization(profile);
  };

  const searchCatalog = async (type: 'mod' | 'modpack', sourceOverride?: CatalogSource, queryOverride?: string) => {
    if (!managedProfile) return;
    const source = sourceOverride ?? catalogSource;
    const query = queryOverride ?? catalogQuery;
    setCatalogLoading(true);
    setCatalogProjects([]);
    setCatalogMessage(`Loading real ${source === 'modrinth' ? 'Modrinth' : 'CurseForge'} ${type === 'mod' ? 'mods' : 'modpacks'} for ${managedProfile.versionId} / ${managedProfile.loader}...`);
    try {
      const result = source === 'modrinth'
        ? await invoke<ModrinthProject[]>('search_modrinth', {
            query,
            projectType: type,
            gameVersion: managedProfile.versionId,
            loader: managedProfile.loader,
          })
        : await invoke<ModrinthProject[]>('search_curseforge', {
            query,
            projectType: type,
            gameVersion: managedProfile.versionId,
            loader: managedProfile.loader,
          });
      setCatalogProjects(result.map((item) => ({ ...item, source })));
      setCatalogMessage(`${result.length} real compatible result(s) loaded from ${source === 'modrinth' ? 'Modrinth' : 'CurseForge'}.`);
    } catch (error) {
      setCatalogProjects([]);
      setCatalogMessage(typeof error === 'string' ? error : `Could not reach ${source}.`);
    } finally {
      setCatalogLoading(false);
    }
  };

  React.useEffect(() => {
    if (!managingModsProfileId || !managedProfile) return;
    if (modLibraryTab !== 'browse-mods' && modLibraryTab !== 'modpacks') return;
    const type = modLibraryTab === 'modpacks' ? 'modpack' : 'mod';
    void searchCatalog(type, catalogSource, '');
  }, [managingModsProfileId, modLibraryTab, catalogSource, managedProfile?.versionId, managedProfile?.loader]);

  const installCatalogProject = async (project: ModrinthProject) => {
    if (!managedProfile) return;
    const source = project.source || catalogSource;
    setCatalogMessage(`Installing ${project.title} from ${source === 'modrinth' ? 'Modrinth' : 'CurseForge'}...`);
    try {
      const result = source === 'modrinth'
        ? await invoke<string>('install_modrinth_project', {
            profileId: managedProfile.id,
            projectId: project.project_id,
            projectType: project.project_type,
            gameVersion: managedProfile.versionId,
            loader: managedProfile.loader,
          })
        : await invoke<string>('install_curseforge_project', {
            profileId: managedProfile.id,
            projectId: project.project_id,
            projectType: project.project_type,
            gameVersion: managedProfile.versionId,
            loader: managedProfile.loader,
          });
      if (project.project_type === 'modpack') {
        setProfiles((current) => current.map((profile) => profile.id === managedProfile.id ? { ...profile, modpack: project.title } : profile));
      } else {
        await refreshLocalMods(managedProfile.id);
      }
      setCatalogMessage(result);
    } catch (error) {
      setCatalogMessage(typeof error === 'string' ? error : `Could not install ${project.title}.`);
    }
  };

  const importLocalMod = async (file?: File) => {
    if (!file || !managedProfile) return;
    if (!file.name.toLowerCase().endsWith('.jar')) {
      setCatalogMessage('Please choose a Minecraft .jar mod file.');
      return;
    }
    setCatalogMessage(`Importing ${file.name}...`);
    try {
      const bytes = Array.from(new Uint8Array(await file.arrayBuffer()));
      const result = await invoke<string>('import_local_mod', {
        profileId: managedProfile.id,
        fileName: file.name,
        bytes,
      });
      await refreshLocalMods(managedProfile.id);
      setCatalogMessage(result);
    } catch {
      setCatalogMessage('Local import needs the Tauri backend. The file was not copied in browser preview mode.');
    }
  };

  const toggleLocalMod = async (mod: LocalMod) => {
    if (!managedProfile) return;
    try {
      await invoke<string>('set_mod_enabled', {
        profileId: managedProfile.id,
        fileName: mod.name,
        enabled: !mod.enabled,
      });
      await refreshLocalMods(managedProfile.id);
    } catch {
      setLocalMods((current) => current.map((item) => item.name === mod.name ? { ...item, enabled: !item.enabled } : item));
      setCatalogMessage('Preview mode: toggle changed in UI only.');
    }
  };

  const deleteLocalMod = async (mod: LocalMod) => {
    if (!managedProfile) return;
    try {
      await invoke<string>('remove_mod', { profileId: managedProfile.id, fileName: mod.name });
      await refreshLocalMods(managedProfile.id);
    } catch {
      setLocalMods((current) => current.filter((item) => item.name !== mod.name));
      setCatalogMessage('Preview mode: mod removed from UI only.');
    }
  };

  const runSystemHealth = async () => {
    if (healthBusy) return;
    setHealthBusy(true);
    const next: HealthItem[] = [];
    const push = (id: string, label: string, state: HealthState, detail: string) => next.push({ id, label, state, detail });

    let config = remoteConfig;
    try {
      const response = await fetch(AXOLOT_PUBLIC_CONFIG_URL, { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      config = await response.json() as RemoteConfig;
      setRemoteConfig(config);
      setMicrosoftClientId((config.microsoft_client_id || '').trim());
      setCurseForgeEnabled(Boolean(config.curseforge_enabled));
      push('cloud', 'Axolot Cloud', 'ok', `Online · admin channel v${config.latest_launcher_version || 'unknown'}`);
    } catch (error) {
      push('cloud', 'Axolot Cloud', 'error', `Unavailable · ${String(error)}`);
    }

    try {
      if (!activeProfile) throw new Error('No active profile');
      const state = await invoke<GameProcessStatus>('get_game_status', { profileId: activeProfile.id });
      push('engine', 'Game engine', 'ok', `${state.state.toUpperCase()} · monitor responding`);
    } catch (error) {
      push('engine', 'Game engine', 'error', String(error));
    }

    try {
      const manifest = (config?.update_manifest_url || updateManifestUrl || DEFAULT_UPDATE_MANIFEST).trim();
      const update = await invoke<LauncherUpdateStatus>('check_launcher_update', { manifestUrl: manifest });
      setUpdateStatus(update);
      push('updates', 'Update channel', 'ok', update.available ? `v${update.latest_version} available` : `Current v${update.current_version}`);
    } catch (error) {
      push('updates', 'Update channel', 'warn', `Could not verify · ${String(error)}`);
    }

    try {
      if (!activeProfile) throw new Error('No active profile');
      const mods = await invoke<ModrinthProject[]>('search_modrinth', {
        query: 'sodium', projectType: 'mod', gameVersion: activeProfile.versionId, loader: activeProfile.loader,
      });
      push('modrinth', 'Modrinth', 'ok', `${mods.length} compatible result(s) returned`);
    } catch (error) {
      push('modrinth', 'Modrinth', 'error', String(error));
    }

    if (!config?.curseforge_enabled) {
      push('curseforge', 'CurseForge', 'warn', 'Admin API key not configured');
    } else {
      try {
        if (!activeProfile) throw new Error('No active profile');
        const mods = await invoke<ModrinthProject[]>('search_curseforge', {
          query: 'sodium', projectType: 'mod', gameVersion: activeProfile.versionId, loader: activeProfile.loader,
        });
        push('curseforge', 'CurseForge', 'ok', `${mods.length} compatible result(s) returned through Axolot Cloud`);
      } catch (error) {
        push('curseforge', 'CurseForge', 'error', String(error));
      }
    }

    setHealthItems(next);
    setHealthBusy(false);
    setStatus(next.every((item) => item.state === 'ok') ? 'System Health: all checked services are ready.' : 'System Health finished with one or more warnings.');
  };

  const filteredProfiles = profiles.filter((profile) => {
    const meta = getVersionMeta(profile.versionId);
    const query = profileSearch.toLowerCase().trim();
    if (!query) return true;
    return (
      profile.name.toLowerCase().includes(query) ||
      profile.versionId.toLowerCase().includes(query) ||
      profile.loader.toLowerCase().includes(query) ||
      meta.title.toLowerCase().includes(query)
    );
  });

  const selectedVersion = getVersionMeta(selectedVersionId);

  return (
    <div className="axo-app">
      <div className="biolume-field" aria-hidden="true">
        <span className="glow-orb orb-a" />
        <span className="glow-orb orb-b" />
        <span className="glow-orb orb-c" />
        <span className="bubble bubble-1" />
        <span className="bubble bubble-2" />
        <span className="bubble bubble-3" />
      </div>
      <div className="motion-field" aria-hidden="true"><span/><span/><span/><span/><span/></div>

      <header className="axo-topbar">
        <button className="axo-brand" onClick={() => setPage('play')}>
          <span className="axo-logo"><i /><b>A</b></span>
          <span className="axo-brand-copy"><strong>AXOLOT CLIENT</strong><small>NEBULA 0.12</small></span>
        </button>

        <nav className="top-nav">
          {nav.map(({ id, icon: Icon, label }) => (
            <button key={id} title={label} aria-label={label} className={page === id ? 'active' : ''} onClick={() => { setPage(id); setCreatingProfile(false); setManagingModsProfileId(null); }}>
              <Icon size={16} /><span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="top-actions">
          {updateStatus?.available && <button className="update-available-chip" onClick={()=>setUpdatePromptOpen(true)}><Download size={14}/><span>Update</span><b>v{updateStatus.latest_version}</b></button>}
          <button className={`status-chip game-${gameStatus?.state || 'stopped'}`} onClick={() => gameStatus?.state === 'crashed' && showCrashCenter()}>
            <span className="status-dot" />
            {gameStatus?.state === 'running' ? `Minecraft running${gameStatus.pid ? ` · ${gameStatus.pid}` : ''}` : gameStatus?.state === 'crashed' ? 'Minecraft crashed' : 'Launcher ready'}
          </button>
          <button className="user-chip" onClick={() => setPage('accounts')}>
            <span className="user-avatar"><User size={16} /></span>
            <span><b>{activeAccount?.username || launcherName || 'Player'}</b><small>{activeAccount?.kind === 'microsoft' ? 'Microsoft account' : 'Offline account'}</small></span>
            <ChevronDown size={14} />
          </button>
          <button className="round-icon"><Bell size={17} /></button>
        </div>
      </header>

      <main className="axo-workspace">
        {page === 'play' && activeProfile && (
          <section className="play-v2-shell">
            <div className="play-v2-main panel-glass">
              <div className="play-v2-copy">
                <span className="micro-label">MINECRAFT</span>
                <h1>Axolot Client</h1>
                <span className="nebula-badge">NEBULA 0.12</span>
                <p>A faster, smoother, more personal way to play Minecraft.</p>
              </div>

              <div className="play-v2-visual" aria-hidden="true">
                <div className="play-v2-orbit orbit-a" />
                <div className="play-v2-orbit orbit-b" />
                <div className="play-v2-orbit orbit-c" />
                <span className="portal-tag play-v2-tag tag-fps">FPS+</span>
                <span className="portal-tag play-v2-tag tag-safe">SAFE</span>
                <span className="portal-tag play-v2-tag tag-core">AXO CORE</span>
                <div className="axo-creature play-v2-creature">
                  <span className="gill gill-l1"/><span className="gill gill-l2"/><span className="gill gill-l3"/>
                  <span className="gill gill-r1"/><span className="gill gill-r2"/><span className="gill gill-r3"/>
                  <div className="axo-head"><span className="eye e1"/><span className="eye e2"/><span className="smile"/></div>
                  <div className="axo-body" />
                </div>
              </div>

              <div className="play-v2-actions">
                <button
                  className="play-v2-launch"
                  disabled={launching || gameStatus?.state === 'running'}
                  onClick={() => launchProfile(activeProfile)}
                  title={gameStatus?.state === 'running' ? 'Minecraft is running' : 'Launch'}
                >
                  {gameStatus?.state === 'running' ? <Activity size={34}/> : <Play size={38} fill="currentColor"/>}
                </button>
                <button className="play-v2-tune" onClick={() => setPage('profiles')} title="Profile settings"><SlidersHorizontal size={25}/></button>
              </div>

              <div className="play-v2-profilebar">
                <button onClick={() => setPage('profiles')}>
                  <span className="pv2-icon"><Gamepad2 size={21}/></span>
                  <span><small>Profile</small><b>{activeProfile.name}</b></span>
                  <ChevronDown size={15}/>
                </button>
                <button onClick={() => setPage('profiles')}>
                  <span className="pv2-icon"><Boxes size={21}/></span>
                  <span><small>Version</small><b>{activeProfile.versionId}</b></span>
                  <ChevronDown size={15}/>
                </button>
                <button onClick={() => setPage('profiles')}>
                  <span className="pv2-icon"><Users size={21}/></span>
                  <span><small>Loader</small><b>{activeProfile.loader}</b></span>
                  <ChevronDown size={15}/>
                </button>
                <button onClick={() => setPage('profiles')}>
                  <span className="pv2-icon"><Cpu size={21}/></span>
                  <span><small>RAM</small><b>{activeProfile.ram} GB</b></span>
                  <ChevronDown size={15}/>
                </button>
              </div>
            </div>

            <aside className="play-v2-side">
              <div className="pv2-status panel-glass">
                <div className="pv2-card-heading">
                  <div><span className="micro-label">CLIENT STATUS</span><h3><i/>{progress === 100 ? 'Client is ready' : status}</h3></div>
                  <button className="pv2-download" onClick={() => updateStatus?.available ? setUpdatePromptOpen(true) : sync()} title={updateStatus?.available ? 'Install update' : 'Sync'}><Download size={20}/></button>
                </div>
                <div className="pulse-bar pv2-progress"><span style={{width: `${progress}%`}} /></div>
                <div className="pv2-status-foot"><small>{progress === 100 ? 'Everything synced' : status}</small><b>{progress}%</b></div>
              </div>

              <div className="pv2-tools panel-glass">
                <span className="micro-label">QUICK TOOLS</span>
                <div className="pv2-tool-grid">
                  <button onClick={() => setPage('profiles')}><Boxes size={23}/><span>Profiles</span></button>
                  <button onClick={() => openModLibrary(activeProfile, 'installed')}><Package size={23}/><span>Mods</span></button>
                  <button onClick={() => openModLibrary(activeProfile, 'modpacks')}><FileArchive size={23}/><span>Modpacks</span></button>
                  <button onClick={showGameConsole}><Terminal size={23}/><span>Live Console</span></button>
                </div>
              </div>

              <button className="pv2-account panel-glass" onClick={() => setPage('accounts')}>
                <span className="pv2-account-icon"><User size={26}/></span>
                <span><small>ACCOUNTS</small><b>{activeAccount?.username || launcherName || 'Player'}</b></span>
                <ChevronRight size={18}/>
              </button>

              <div className="pv2-performance panel-glass">
                <span className="micro-label">PERFORMANCE</span>
                <div className="pv2-perf-grid">
                  <button onClick={() => setPage('settings')}>
                    <Zap size={24}/><span>AutoBoost</span><b className={activeProfile.autoOptimized ? 'on' : 'off'}>{activeProfile.autoOptimized ? '● ON' : '○ OFF'}</b>
                  </button>
                  <button onClick={() => openModLibrary(activeProfile, 'installed')}>
                    <Package size={24}/><span>Local Mods</span><b className="on">{localMods.length}</b>
                  </button>
                  <button onClick={() => showGameConsole()}>
                    <Gamepad2 size={24}/><span>Game Runtime</span><b className={gameStatus?.state === 'running' ? 'on' : 'off'}>{gameStatus?.state === 'running' ? '● ON' : '○ IDLE'}</b>
                  </button>
                </div>
              </div>
            </aside>
          </section>
        )}

        {page === 'profiles' && !creatingProfile && !managingModsProfileId && (
          <section className="profiles-new">
            <div className="page-heading-new">
              <div><span className="micro-label">INSTANCES</span><h1>Your Minecraft,<br/><em>organized.</em></h1></div>
              <div className="heading-actions">
                <label className="search-pill"><Search size={16}/><input value={profileSearch} onChange={(e)=>setProfileSearch(e.target.value)} placeholder="Search profiles"/></label>
                <button className="accent-action" onClick={() => { setCreatingProfile(true); setNewProfileName(`My ${selectedVersionId} ${selectedLoader}`); }}><Plus size={16}/> Create profile</button>
              </div>
            </div>

            <div className="instance-grid">
              {filteredProfiles.map((profile, index) => (
                <article key={profile.id} className={`instance-card palette-${(index % 4)+1} ${activeProfileId===profile.id?'active':''}`}>
                  <div className="instance-top">
                    <span className="instance-orb"><Gamepad2 size={22}/></span>
                    <div className="instance-flags">
                      {profile.isDefault && <span>DEFAULT</span>}
                      {profile.autoOptimized && <span className="boost"><Zap size={10}/> BOOST</span>}
                    </div>
                  </div>
                  <div className="instance-copy"><h3>{profile.name}</h3><p>{profile.versionId} · {profile.loader}</p></div>
                  <div className="instance-stats"><span><Cpu size={13}/>{profile.ram} GB</span><span><Package size={13}/>{profile.modpack || 'Custom'}</span></div>
                  <div className="instance-actions">
                    <button className="instance-play" disabled={launching} onClick={() => launchProfile(profile)}><Play size={15}/> Play</button>
                    <button className="instance-mods" onClick={() => openModLibrary(profile,'installed')}>Mods</button>
                    <button className="instance-icon-action instance-folder" title="Open profile folder" aria-label="Open profile folder" onClick={() => openProfileFolder(profile)}><FolderOpen size={16}/></button>
                    <button className="instance-icon-action instance-more" title="Profile options" aria-label="Profile options" onClick={() => makeDefault(profile.id)}><CircleEllipsis size={16}/></button>
                  </div>
                </article>
              ))}

              <button className="instance-create" onClick={() => setCreatingProfile(true)}>
                <span><Plus size={30}/></span><b>Create new world profile</b><small>Version · loader · RAM · AutoBoost</small>
              </button>
            </div>
          </section>
        )}

        {page === 'profiles' && creatingProfile && !managingModsProfileId && (
          <section className="creator-shell">
            <div className="creator-intro">
              <button className="back-link" onClick={()=>setCreatingProfile(false)}>← Back to profiles</button>
              <span className="micro-label">PROFILE LAB</span>
              <h1>Build your<br/><em>perfect instance.</em></h1>
              <p>Choose a Minecraft base, loader and memory. Axolot can install its performance stack automatically for Fabric.</p>
              <div className="creator-steps"><span className="done">1</span><i/><span className="active">2</span><i/><span>3</span></div>
            </div>

            <div className="creator-board panel-glass">
              <div className="version-carousel">
                {versionCatalog.map((version) => (
                  <button key={version.id} className={selectedVersionId===version.id?'active':''} onClick={()=>{setSelectedVersionId(version.id);setNewProfileName(`My ${version.id} ${selectedLoader}`);}}>
                    <span className="version-glyph">{version.id.split('.').slice(-1)[0]}</span>
                    <b>{version.title}</b><small>{version.label}</small>
                  </button>
                ))}
              </div>

              <div className="creator-form-grid">
                <label><span>Profile name</span><input value={newProfileName} onChange={(e)=>setNewProfileName(e.target.value)} /></label>
                <label><span>Optional modpack</span><input value={newProfileModpack} onChange={(e)=>setNewProfileModpack(e.target.value)} placeholder="Leave empty for custom" /></label>
                <label><span>Minecraft</span><select value={selectedVersionId} onChange={(e)=>setSelectedVersionId(e.target.value)}>{versionCatalog.map(v=><option key={v.id} value={v.id}>{v.title}</option>)}</select></label>
                <label><span>Loader</span><select value={selectedLoader} onChange={(e)=>setSelectedLoader(e.target.value as Loader)}><option>Fabric</option><option>Vanilla</option><option disabled>Forge — coming next</option><option disabled>NeoForge — coming next</option></select></label>
              </div>

              <div className="memory-lab">
                <div><span>Memory allocation</span><b>{newProfileRam.toFixed(1)} GB</b></div>
                <input type="range" min="2" max="12" step="0.5" value={newProfileRam} onChange={(e)=>setNewProfileRam(Number(e.target.value))}/>
                <small>Axolot tunes the optimization preset based on RAM.</small>
              </div>

              <div className={`boost-lab ${selectedLoader==='Fabric'?'ready':'off'}`}>
                <span className="boost-lab-icon"><Zap size={20}/></span>
                <div><b>Axolot AutoBoost</b><p>{selectedLoader==='Fabric'?'Automatic Sodium + Lithium + FerriteCore + ImmediatelyFast + EntityCulling + Axolot Core setup.':'Switch to Fabric to enable the automatic Axolot performance stack.'}</p></div>
                <span className="boost-state">{selectedLoader==='Fabric'?'READY':'FABRIC ONLY'}</span>
              </div>

              <button className="creator-submit" onClick={createProfile}><Sparkles size={17}/> Create & optimize {selectedVersion.id}</button>
            </div>
          </section>
        )}

        {page === 'profiles' && managingModsProfileId && managedProfile && (
          <section className="library-shell">
            <div className="library-hero panel-glass">
              <button className="back-link" onClick={()=>setManagingModsProfileId(null)}>← Profiles</button>
              <div className="library-title"><span className="library-icon"><Package size={23}/></span><div><span className="micro-label">PROFILE LIBRARY</span><h1>{managedProfile.name}</h1><p>{managedProfile.versionId} · {managedProfile.loader} · {managedProfile.ram} GB</p></div></div>
              <div className="library-actions"><label className="file-add"><Plus size={15}/> Add .jar<input type="file" accept=".jar,application/java-archive" onChange={(e)=>{void importLocalMod(e.target.files?.[0]);e.currentTarget.value='';}}/></label><button className="accent-action" onClick={()=>launchProfile(managedProfile)}><Play size={15}/> Play</button></div>
            </div>

            <div className="library-tabs">
              <button className={modLibraryTab==='installed'?'active':''} onClick={()=>setModLibraryTab('installed')}><HardDrive size={15}/> My mods <span>{localMods.length}</span></button>
              <button className={modLibraryTab==='browse-mods'?'active':''} onClick={()=>{setModLibraryTab('browse-mods');setCatalogProjects([]);}}><Search size={15}/> Discover mods</button>
              <button className={modLibraryTab==='modpacks'?'active':''} onClick={()=>{setModLibraryTab('modpacks');setCatalogProjects([]);}}><FileArchive size={15}/> Modpacks</button>
            </div>

            {modLibraryTab==='installed' && (
              <div className="mods-bento">
                <div className="mods-list panel-glass">
                  <label className="search-pill full"><Search size={16}/><input value={modFileSearch} onChange={(e)=>setModFileSearch(e.target.value)} placeholder="Search installed mods"/></label>
                  <div className="mod-rows-new">
                    {localMods.filter(m=>m.name.toLowerCase().includes(modFileSearch.toLowerCase())).map((mod)=>(
                      <div className="mod-row-new" key={mod.name}>
                        <span className="mod-dot"><Package size={17}/></span><div><b>{mod.name.replace(/\.disabled$/,'')}</b><small>{(mod.size_bytes/1024/1024).toFixed(2)} MB · local jar</small></div>
                        <button className={`neo-toggle ${mod.enabled?'on':''}`} onClick={()=>void toggleLocalMod(mod)}><span/></button>
                        <button className="trash-btn" onClick={()=>void deleteLocalMod(mod)}><Trash2 size={15}/></button>
                      </div>
                    ))}
                    {localMods.length===0 && <div className="empty-library"><Package size={30}/><h3>No mods here yet</h3><p>Drop in a .jar or discover compatible mods.</p><button className="accent-action" onClick={()=>setModLibraryTab('browse-mods')}><Search size={15}/> Discover</button></div>}
                  </div>
                </div>
                <aside className="profile-orbit panel-glass"><span className="micro-label">PROFILE ORBIT</span><div className="orbit-stat"><span>Minecraft</span><b>{managedProfile.versionId}</b></div><div className="orbit-stat"><span>Loader</span><b>{managedProfile.loader}</b></div><div className="orbit-stat"><span>Memory</span><b>{managedProfile.ram} GB</b></div><div className="orbit-stat"><span>Pack</span><b>{managedProfile.modpack||'Custom'}</b></div><div className="safe-note"><ShieldCheck size={16}/><span>Compatibility filters are applied for this profile.</span></div></aside>
              </div>
            )}

            {(modLibraryTab==='browse-mods'||modLibraryTab==='modpacks') && (
              <div className="discover-shell">
                <div className="discover-toolbar panel-glass">
                  <div className="provider-switch">
                    <button className={catalogSource==='modrinth'?'active':''} onClick={()=>{setCatalogSource('modrinth');setCatalogProjects([]);setCatalogMessage('Loading real Modrinth catalog…');}}>Modrinth</button>
                    <button className={catalogSource==='curseforge'?'active':''} onClick={()=>{setCatalogSource('curseforge');setCatalogProjects([]);setCatalogMessage(curseForgeEnabled?'Loading real CurseForge catalog…':'CurseForge is not configured by the Axolot administrator yet.');}}>CurseForge</button>
                  </div>
                  <label className="search-pill full"><Search size={16}/><input value={catalogQuery} onChange={(e)=>setCatalogQuery(e.target.value)} onKeyDown={(e)=>{if(e.key==='Enter')void searchCatalog(modLibraryTab==='modpacks'?'modpack':'mod');}} placeholder={`Search ${modLibraryTab==='modpacks'?'modpacks':'mods'} for ${managedProfile.versionId}`}/></label>
                  <button className="accent-action" disabled={catalogLoading} onClick={()=>void searchCatalog(modLibraryTab==='modpacks'?'modpack':'mod')}>{catalogLoading?'Searching…':'Search'}</button>
                </div>
                <p className="catalog-note">{catalogMessage}</p>
                <div className="project-grid-new">
                  {catalogLoading && Array.from({length:6}).map((_,index)=><div className="project-skeleton" key={`skeleton-${index}`}><span/><b/><i/></div>)}
                  {!catalogLoading && catalogProjects.length===0 && <div className="catalog-empty"><Search size={28}/><h3>No compatible results loaded</h3><p>{catalogMessage}</p></div>}
                  {catalogProjects.map((project,index)=>(
                    <article className={`project-card-new tone-${(index%4)+1}`} key={`${project.project_id}-${index}`}>
                      <div className="project-icon-new">{project.icon_url?<img src={project.icon_url} alt=""/>:<Package size={25}/>}</div>
                      <span className="project-kind">{project.source === 'curseforge' ? 'CURSEFORGE' : 'MODRINTH'} · {project.project_type==='modpack'?'MODPACK':'MOD'}</span>
                      <h3>{project.title}</h3><p>{project.description}</p>
                      <div className="project-tags">{(project.categories||[]).slice(0,3).map(c=><span key={c}>{c}</span>)}</div>
                      <button onClick={()=>void installCatalogProject(project)}><Download size={15}/>{project.project_type==='modpack'?'Install pack':'Install mod'}</button>
                    </article>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}


        {page === 'accounts' && (
          <section className="accounts-page">
            <div className="page-heading-new">
              <div>
                <span className="micro-label">IDENTITY VAULT</span>
                <h1>Switch accounts.<br/><em>Keep every world yours.</em></h1>
                <p className="account-lead">Store multiple launcher identities and choose exactly which account Axolot uses before starting Minecraft.</p>
              </div>
              <div className="account-active-summary panel-glass">
                <span className="user-avatar large"><User size={20}/></span>
                <span><small>ACTIVE ACCOUNT</small><b>{activeAccount?.username || 'Player'}</b></span>
                <span className="active-check"><CheckCircle2 size={16}/> Active</span>
              </div>
            </div>

            <div className="account-layout">
              <div className="account-library panel-glass">
                <div className="account-library-head">
                  <div><span className="micro-label">SAVED ACCOUNTS</span><h2>{accounts.length} identities</h2><small>{offlineAccountCount} Offline / Crack · {microsoftAccountCount} Microsoft</small></div>
                  <label className="search-pill"><Search size={15}/><input value={accountSearch} onChange={(e)=>setAccountSearch(e.target.value)} placeholder="Search accounts"/></label>
                </div>
                <div className="account-filter-bar">
                  <button className={accountFilter==='all'?'active':''} onClick={()=>setAccountFilter('all')}>All <span>{accounts.length}</span></button>
                  <button className={accountFilter==='offline'?'active':''} onClick={()=>setAccountFilter('offline')}>Offline / Crack <span>{offlineAccountCount}</span></button>
                  <button className={accountFilter==='microsoft'?'active':''} onClick={()=>setAccountFilter('microsoft')}>Microsoft <span>{microsoftAccountCount}</span></button>
                </div>

                <div className="account-grid">
                  {visibleAccounts.map((account)=>(
                    <article key={account.id} className={`account-card-new ${account.id === activeAccount?.id ? 'active' : ''}`}>
                      <div className="account-card-top">
                        <span className={`account-avatar ${account.kind}`}><User size={22}/></span>
                        <span className="account-type">{account.kind === 'microsoft' ? 'MICROSOFT' : 'OFFLINE / CRACK'}</span>
                        {account.kind === 'microsoft' && <span className={`session-dot ${microsoftSessionStates[account.id] === true ? 'ready' : microsoftSessionStates[account.id] === null ? 'checking' : 'reauth'}`}>{microsoftSessionStates[account.id] === true ? 'READY' : microsoftSessionStates[account.id] === null ? 'CHECKING' : 'SAVED'}</span>}
                      </div>
                      <h3>{account.username}</h3>
                      <p>{account.kind === 'offline' ? 'Offline/crack identity · no Microsoft sign-in required' : 'Premium identity · refresh token stored securely in Windows Credential Manager'}</p>
                      <div className="account-card-actions">
                        <button className={account.id === activeAccount?.id ? 'selected-account' : 'accent-action'} disabled={account.id === activeAccount?.id} onClick={()=>selectAccount(account)}>
                          {account.id === activeAccount?.id ? <><CheckCircle2 size={15}/> Active</> : <><LogIn size={15}/> Use account</>}
                        </button>
                        <button className="trash-btn" title="Remove account" onClick={()=>deleteAccount(account.id)}><Trash2 size={15}/></button>
                      </div>
                    </article>
                  ))}
                </div>
              </div>

              <aside className="account-create panel-glass">
                <span className="micro-label">ADD IDENTITIES</span>
                <div className="account-create-icon"><UserPlus size={24}/></div>
                <h2>Unlimited account vault</h2>
                <p>Add as many Offline/Crack and Microsoft accounts as you need, then switch the active identity with one click.</p>
                <label><span>One offline username</span><input value={newAccountName} onChange={(e)=>setNewAccountName(sanitizeMinecraftName(e.target.value))} onKeyDown={(e)=>{if(e.key==='Enter')addOfflineAccount();}} placeholder="Example: DiskiiVN_Alt"/></label>
                <button className="creator-submit" onClick={addOfflineAccount}><UserPlus size={16}/> Add offline account</button>
                <label className="bulk-account-field"><span>Add many Offline / Crack accounts</span><textarea value={bulkAccountNames} onChange={(e)=>setBulkAccountNames(e.target.value)} placeholder={'Builder01\nPvP_Alt\nFarmAccount'}/><small>Separate usernames with new lines, spaces or commas.</small></label>
                <button className="secondary-account-action" onClick={addOfflineAccountsBulk}><Users size={16}/> Add multiple accounts</button>

                <div className="microsoft-connect">
                  <span className="microsoft-icon"><ShieldCheck size={20}/></span>
                  <div><b>Add another Microsoft / Premium account</b><p>Every Microsoft identity is saved separately. Refresh credentials stay in the Windows credential vault, not localStorage.</p></div>
                  <button onClick={connectMicrosoftAccount} disabled={microsoftBusy}>{microsoftBusy ? 'Waiting…' : 'Connect another'}</button>
                </div>
              </aside>
            </div>
          </section>
        )}

        {page === 'partners' && (
          <section className="simple-page"><div><span className="micro-label">COMMUNITY</span><h1>Partner reef</h1><p>Featured servers and creators can live here without copying another launcher layout.</p></div><div className="placeholder-world panel-glass"><Handshake size={48}/><b>Partner ecosystem</b><small>Coming in a later Axolot release.</small></div></section>
        )}

        {page === 'store' && (
          <section className="simple-page"><div><span className="micro-label">COSMETICS</span><h1>Axolot market</h1><p>A future home for capes, themes, cosmetics and client perks.</p></div><div className="placeholder-world panel-glass"><ShoppingCart size={48}/><b>Store in development</b><small>Launcher commerce is not enabled yet.</small></div></section>
        )}

        {page === 'settings' && (
          <section className="settings-new">
            <div className="page-heading-new"><div><span className="micro-label">SYSTEM</span><h1>Make Axolot<br/><em>feel yours.</em></h1></div><button className="accent-action" onClick={saveSettings}>Save changes</button></div>
            <div className="settings-bento">
              <label className="setting-tile panel-glass"><span>Active offline username</span><input value={launcherName} onChange={(e)=>renameActiveOfflineAccount(e.target.value)} disabled={activeAccount?.kind !== 'offline'}/><small>Rename the currently active offline account. Manage all accounts from the Accounts tab.</small></label>
              <label className="setting-tile panel-glass"><span>Default memory</span><b className="memory-big">{globalRam} GB</b><input type="range" min="2" max="16" value={globalRam} onChange={(e)=>setGlobalRam(Number(e.target.value))}/><small>Recommended 4–8 GB.</small></label><label className="setting-tile panel-glass"><span>Quick connect server</span><input value={serverAddress} onChange={(e)=>setServerAddress(e.target.value)} placeholder="play.yourserver.com:25565"/><small>Leave empty to open the normal multiplayer menu.</small></label>
              <div className="setting-tile panel-glass cloud-managed"><span>CurseForge catalog</span><b>{curseForgeEnabled ? 'Managed by Axolot Cloud' : 'Waiting for admin setup'}</b><small>The CurseForge API key stays on Axolot's backend and is never shipped to players.</small></div>
              <div className="setting-tile panel-glass cloud-managed"><span>Microsoft sign-in</span><b>{microsoftClientId ? 'Managed by Axolot Cloud' : 'Waiting for admin setup'}</b><small>The public Client ID is delivered automatically. Players never need to paste IDs or secrets.</small></div>
              <div className="setting-tile panel-glass update-setting"><span>Automatic update alerts</span><b>{updateStatus?.available ? `v${updateStatus.latest_version} available` : 'Stable channel'}</b><label className="toggle-row"><input type="checkbox" checked={autoInstallUpdates} onChange={(e)=>setAutoInstallUpdates(e.target.checked)}/> Check automatically and show new releases on screen</label><div className="setting-actions"><button onClick={checkForUpdates}>Check now</button>{updateStatus?.available && <button className="accent-action" onClick={()=>setUpdatePromptOpen(true)}>View update</button>}</div><small>Axolot checks at startup and while the launcher is open. Updates are SHA-256 verified and installed in-app only after you press Update now.</small></div>
              <div className="setting-tile panel-glass cloud-managed"><span>Release channel</span><b>Axolot Stable</b><small>{remoteConfig?.latest_launcher_version ? `Admin channel reports v${remoteConfig.latest_launcher_version}` : 'Managed remotely by Axolot Cloud.'}</small></div>
              <div className="setting-tile panel-glass health-tile"><div className="health-head"><div><span>SYSTEM HEALTH</span><b>Launcher diagnostics</b></div><button onClick={runSystemHealth} disabled={healthBusy}><Activity size={14}/>{healthBusy ? 'Checking…' : 'Run check'}</button></div><div className="health-list">{healthItems.map((item)=><div className={`health-row ${item.state}`} key={item.id}><i/><span><b>{item.label}</b><small>{item.detail}</small></span></div>)}</div><small>Checks Axolot Cloud, game process monitor, update channel and both mod providers without exposing private API keys.</small></div>
              <div className="security-tile panel-glass"><span className="security-icon"><ShieldCheck size={22}/></span><div><b>Microsoft secure sign-in</b><p>Axolot uses Microsoft Device Code OAuth → Xbox Live/XSTS → Minecraft Services. It never asks for your Microsoft password. The Axolot administrator configures Microsoft centrally; players never enter a Client ID.</p></div></div>
              <div className="setting-tile panel-glass"><span>Theme</span><b>Nebula Dark</b><small>Axolot-exclusive visual system.</small></div>
            </div>
          </section>
        )}
      </main>

      {launching && (
        <div className="launch-overlay">
          <div className="launch-dialog panel-glass">
            <span className="micro-label">AXOLOT GAME ENGINE</span>
            <div className="launch-spinner"><span/><i/></div>
            <h2>{status}</h2>
            <p>{launchStage === 'java' ? 'Java runtime is downloaded only when needed.' : 'First launch can take a few minutes while Minecraft assets and libraries are installed.'}</p>
            <div className="release-progress"><span style={{ width: `${progress}%` }}/></div>
            <div className="release-progress-meta"><span>{launchStage.toUpperCase()}</span><b>{progress}%</b></div>
          </div>
        </div>
      )}

      {booting && (
        <div className="boot-overlay">
          <div className="boot-atmosphere" aria-hidden="true"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div>
          <div className="boot-radar" aria-hidden="true"><span/><b/><i/></div>
          <div className="boot-core">
            <div className="boot-axo"><span>A</span><i/><b/></div>
            <span className="micro-label">AXOLOT NEBULA 0.12.4</span>
            <h2>Waking the lagoon...</h2>
            <p>{bootMessage}</p>
            <div className="boot-line"><span style={{width:`${bootPercent}%`}}/></div>
            <div className="boot-percent"><span>BOOT SEQUENCE</span><b>{bootPercent}%</b></div>
          </div>
        </div>
      )}

      {updatePromptOpen && updateStatus?.available && (
        <div className="update-overlay">
          <div className="update-dialog panel-glass">
            <div className="update-radiance" aria-hidden="true"><i/><i/><i/></div>
            <div className="update-head">
              <span className="update-glyph"><Download size={22}/></span>
              <div><span className="micro-label">AXOLOT UPDATE CHANNEL</span><h2>Axolot {updateStatus.latest_version} is ready</h2></div>
              {!updateStatus.mandatory && !updatingLauncher && <button className="update-close" onClick={()=>{sessionStorage.setItem('axolot.dismissedUpdateVersion', updateStatus.latest_version);setUpdatePromptOpen(false);}}><X size={16}/></button>}
            </div>
            <p className="update-lead">Axolot found a newer build. Automatic mode downloads it inside the launcher, verifies SHA-256, starts the installer, then closes this version.</p>
            <div className="update-version-rail"><span><small>INSTALLED</small><b>v{updateStatus.current_version}</b></span><i><ChevronRight size={16}/></i><span className="next"><small>AVAILABLE</small><b>v{updateStatus.latest_version}</b></span></div>
            <div className="update-notes"><span className="micro-label">WHAT'S NEW</span><p>{updateStatus.notes || 'Performance, stability and launcher experience improvements.'}</p></div>
            <div className="update-trust"><ShieldCheck size={15}/><span>Installer is downloaded inside Axolot and verified against the release SHA-256 before installation.</span></div>
            <div className="update-actions">
              <button className="update-now" onClick={installUpdateNow} disabled={updatingLauncher}><Download size={16}/>{updatingLauncher ? 'Downloading & verifying…' : 'Update now'}</button>
              {!updateStatus.mandatory && <button disabled={updatingLauncher} onClick={()=>{sessionStorage.setItem('axolot.dismissedUpdateVersion', updateStatus.latest_version);setUpdatePromptOpen(false);}}>Later</button>}
            </div>
            <small className="update-foot">Hands-free updates are enabled by default. While Minecraft is running, Axolot defers installation until it is safe to update.</small>
          </div>
        </div>
      )}

      {microsoftDevice && (
        <div className="microsoft-overlay">
          <div className={`microsoft-dialog panel-glass ${microsoftError ? 'has-error' : ''}`}>
            <span className="micro-label">MICROSOFT SECURE SIGN-IN</span>
            <div className="microsoft-orb">{microsoftError ? <AlertTriangle size={30}/> : <ShieldCheck size={30}/>}</div>
            <h2>{microsoftError ? (microsoftNeedsApproval ? 'Minecraft AppID approval required' : 'Microsoft signed in, but Minecraft could not finish') : 'Link your Minecraft account'}</h2>
            <p>{microsoftError ? (microsoftNeedsApproval ? 'Microsoft, Xbox Live and XSTS are already working. Minecraft Services is blocking this new Axolot Client ID until Mojang/Minecraft approves it.' : 'Axolot reached an error after or during Microsoft authorization. The exact backend response is shown below.') : 'Open Microsoft sign-in and enter this one-time code. Axolot will continue through Xbox and Minecraft Services automatically.'}</p>
            {!microsoftError && <button className="device-code" onClick={()=>navigator.clipboard?.writeText(microsoftDevice.user_code)}>{microsoftDevice.user_code}</button>}
            {microsoftError && <div className={`microsoft-error-box ${microsoftNeedsApproval ? 'approval' : ''}`}><b>{microsoftNeedsApproval ? 'MINECRAFT SERVICES GATE' : 'LOGIN DIAGNOSTIC'}</b><span>{microsoftError}</span>{microsoftNeedsApproval && <small>Axolot cannot bypass this server-side allowlist. Submit the Axolot Client ID once, then Premium login will start working without another launcher update.</small>}</div>}
            {microsoftNeedsApproval ? (
              <div className="minecraft-approval-actions">
                <button className="accent-action wide" onClick={openMinecraftApproval}><ShieldCheck size={15}/> Apply for Minecraft access</button>
                <button onClick={()=>navigator.clipboard?.writeText(microsoftClientId.trim())}>Copy Client ID</button>
                <button onClick={continueOfflineAfterMicrosoftBlock}><Play size={15}/> Continue Offline</button>
                <button onClick={()=>{setMicrosoftDevice(null);setMicrosoftError('');setMicrosoftStage('');void connectMicrosoftAccount();}}><RefreshCw size={15}/> Retry after approval</button>
              </div>
            ) : (
              <div className="microsoft-modal-actions">
                {microsoftError ? (
                  <>
                    <button className="accent-action" onClick={()=>{setMicrosoftDevice(null);setMicrosoftError('');setMicrosoftStage('');void connectMicrosoftAccount();}}><RefreshCw size={15}/> Try again</button>
                    <button onClick={()=>{setMicrosoftDevice(null);setMicrosoftError('');setMicrosoftStage('');}}>Close</button>
                  </>
                ) : (
                  <>
                    <button className="accent-action" onClick={()=>void invoke('open_external_url',{url:microsoftDevice.verification_uri})}><LogIn size={15}/> Open Microsoft</button>
                    <button onClick={()=>navigator.clipboard?.writeText(microsoftDevice.user_code)}>Copy code</button>
                  </>
                )}
              </div>
            )}
            <small>{microsoftStage || (microsoftBusy ? 'Waiting for Microsoft authorization…' : microsoftDevice.message)}</small>
          </div>
        </div>
      )}

      {consoleOpen && (
        <div className="console-overlay" onClick={()=>setConsoleOpen(false)}>
          <div className="console-window" onClick={(e)=>e.stopPropagation()}>
            <div className="console-head">
              <div><span className="micro-label">LIVE CONSOLE</span><h3>{activeProfile?.name} · {gameStatus?.state?.toUpperCase() || 'STOPPED'}</h3></div>
              <div className="console-actions">
                {gameStatus?.state === 'crashed' && <button className="danger-button" onClick={showCrashCenter}><AlertTriangle size={14}/> Crash Center</button>}
                <button onClick={()=>setConsoleOpen(false)}><X size={14}/> Close</button>
              </div>
            </div>
            <pre>{consoleText}</pre>
            <div ref={consoleEndRef} />
          </div>
        </div>
      )}

      {crashOpen && crashReport && (
        <div className="crash-overlay" onClick={()=>setCrashOpen(false)}>
          <div className="crash-window" onClick={(e)=>e.stopPropagation()}>
            <div className="crash-head">
              <div className="crash-title">
                <span className="crash-icon"><AlertTriangle size={22}/></span>
                <div><span className="micro-label">AXOLOT CRASH CENTER</span><h2>Minecraft crashed</h2><p>{crashReport.summary}</p></div>
              </div>
              <button onClick={()=>setCrashOpen(false)}><X size={18}/></button>
            </div>

            <div className="crash-meta">
              <span><b>Exit code</b>{crashReport.exit_code ?? 'unknown'}</span>
              <span><b>Profile</b>{activeProfile?.name || crashReport.profile_id}</span>
              <span className="crash-source"><b>Source</b>{crashReport.source}</span>
            </div>

            <div className="crash-columns">
              <section className="crash-suspects">
                <div className="crash-section-head"><div><span className="micro-label">SUSPECT LINES</span><h3>Likely cause</h3></div><span>{crashReport.suspicious.length} matches</span></div>
                <div className="crash-lines compact">
                  {crashReport.suspicious.length ? crashReport.suspicious.map((line) => (
                    <div key={`sus-${line.number}-${line.text}`} className={`crash-line level-${line.level}`}>
                      <span className="line-number">{line.number}</span><span className="line-level">{line.level}</span><code>{line.text}</code>
                    </div>
                  )) : <div className="empty-crash">No obvious ERROR/Exception line was detected. Check the full report.</div>}
                </div>
              </section>

              <section className="crash-full">
                <div className="crash-section-head"><div><span className="micro-label">FULL REPORT</span><h3>Line-by-line details</h3></div><span>{crashReport.lines.length} lines</span></div>
                <div className="crash-lines">
                  {crashReport.lines.map((line) => (
                    <div key={`${line.number}-${line.text}`} className={`crash-line level-${line.level}`}>
                      <span className="line-number">{line.number}</span><span className="line-level">{line.level}</span><code>{line.text || ' '}</code>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
