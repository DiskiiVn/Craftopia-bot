# Axolot Client 0.12.4 RC

## Desktop launcher UI refresh

- Rebuilt the Play screen to match the approved Axolot desktop launcher concept.
- Fixed left navigation rail with short labels instead of a website-style top navigation experience.
- Removed the large marketing headline and removed the `PLAY MINECRAFT` text label.
- Large centered gradient launch control with profile tuning shortcut.
- New bottom profile strip for Profile, Version, Loader and RAM.
- New right rail with Client Status, Quick Tools, Accounts and Performance cards.
- Whole launcher window stays fixed. Only content-heavy sub-pages scroll inside their own panels.
- Auto Update remains pointed at the Supabase stable channel and validates SHA-256 before installation.
