# Axolot Client v0.10.1 Release Candidate

Premium Nebula UI release candidate.

Highlights:
- Reworked Identity Vault / multi-account manager UI
- Polished launcher navigation, panels, profile cards and motion
- Minecraft running / stopped / crashed monitor
- Live console and Crash Center
- Fabric profile AutoBoost with Sodium, Lithium, FerriteCore, ImmediatelyFast, EntityCulling, Dynamic FPS and Mod Menu
- Modrinth + CurseForge catalog support (CurseForge requires an API key / backend proxy for public release)
- Windows release build hides the console window

This release keeps the existing Minecraft launch backend and account/profile data format from v0.9.x.

## Axolot v0.11 release systems

### Microsoft / Premium login
Axolot v0.11 uses Microsoft Device Code OAuth. Register Axolot as your own public/native Microsoft application, enable public client flows, and paste the application's Client ID in **Settings → Microsoft App Client ID**. The launcher never asks for a Microsoft password or client secret. The login chain is Microsoft OAuth → Xbox Live → XSTS → Minecraft Services → ownership/profile verification.

### Automatic updates
Axolot checks `https://github.com/DiskiiVn/Craftopia-bot/releases/latest/download/axolot-update.json` at startup. The release workflow builds the NSIS installer, calculates SHA-256, publishes the installer + manifest to GitHub Releases, and the launcher downloads/verifies/installs the new version silently. Users do not need to manually download a new installer.


## v0.12.0 cloud-managed configuration

Axolot now downloads public launcher configuration from the Axolot backend at startup. End users never paste a Microsoft Client ID or CurseForge API key. The Microsoft Client ID is a public identifier delivered by `axolot-public-config`; CurseForge traffic is routed through `axolot-curseforge`, where the secret API key stays server-side.

Admin portal: `https://axolot-client-updates-pter.vercel.app`


## v0.12.0 Microsoft sign-in diagnostics

- Device Code polling follows Microsoft `interval`, handles `authorization_pending`, `slow_down`, decline and expiry.
- The login modal now surfaces the exact post-OAuth failure instead of staying on “Waiting”.
- Minecraft Services HTTP 403 `Invalid app registration` is detected explicitly. A new Entra Client ID can complete Microsoft OAuth while still requiring Minecraft approval/allowlisting before Java Premium authentication can finish.


## v0.12 Motion Core
- Premium motion layer with animated nebula, portal, cards, navigation, launch shimmer and accessibility-friendly reduced-motion fallback.
- System Health panel checks Axolot Cloud, game monitor, updater, Modrinth and CurseForge.
- Microsoft sign-in diagnostics surface OAuth/Xbox/XSTS/Minecraft Services errors instead of leaving the Device Code dialog stuck.
- Existing AutoBoost, multi-account, live console, crash center, cloud-managed CurseForge and auto-updater remain included.


## v0.12.1 Minecraft AppID approval handling
- Detects Minecraft Services HTTP 403 `Invalid app registration` as a server-side AppID allowlist issue.
- Provides an in-launcher button to open the official Minecraft AppID approval form and copies the configured Axolot Client ID.
- Adds a safe Offline fallback for compatible/private servers while Premium access is awaiting approval.
- Existing v0.12.0 clients receive v0.12.1 through the built-in verified updater; users do not need to manually download a new installer.
- The launcher does not reuse another launcher's Client ID and does not attempt to bypass Minecraft Services authorization.


## v0.12.4 Multi Identity Vault
- Unlimited Offline/Crack identities with single-add and bulk-add support.
- Multiple Microsoft/Premium identities can coexist in the same launcher.
- Microsoft refresh tokens are stored in the OS credential vault via the Rust keyring backend, never in localStorage.
- Saved Microsoft accounts restore sessions automatically on launcher start and before Play.
- Account filters, identity counts, session status badges and one-click active-account switching.
- Offline and Microsoft accounts may share the same visible Minecraft username without colliding.
- Minecraft AppID approval handling from v0.12.1 remains in place.


## v0.12.4 Fixed Desktop Shell + Hands-free Update
- Play is now a fixed desktop dashboard: no full-window page scrolling and no marketing-style hero copy.
- Navigation is a compact icon rail on the left; only content-heavy views such as Profiles, Mods, Accounts and Settings scroll inside their own panels.
- The launch control is icon-first and no longer displays “Play Minecraft”.
- Automatic updates are enabled by default. On startup Axolot checks the signed release channel, downloads the NSIS installer internally, verifies SHA-256, starts the silent installer, then exits the old build.
- Background update checks run when the launcher regains focus and every 10 minutes. If Minecraft is currently running, Axolot defers installation instead of interrupting the session.
- GitHub Actions builds the Windows NSIS installer and publishes `axolot-update.json` automatically for `axolot-v*` tags.
